# Official sources consulted, 2026-10-21 UTC

The following were retrieved remotely as inert documentation/data. No vendor
binary was executed. The approved www.python.org HTTPS download used the existing
enforced proxy; no bypass, policy removal/re-add, mixed-draft publication, stale
setup execution, or workspace reset was performed. An earlier 403 is retained
in Cloud temporary download headers. A fresh request after the domain review
succeeded even though the status tool still showed revision 1 / network unknown.
We therefore establish successful approved-proxy retrieval, not configuration
publication or future environment restoration.

| Source | Application and limits |
| --- | --- |
| https://www.python.org/downloads/release/python-31316/ | Exact AMD64 embeddable ZIP, SHA256, Sigstore and SPDX links independently read in Cloud. 3.13.17 supersession is acknowledged; no version change authorized or performed. |
| https://www.python.org/ftp/python/3.13.16/python-3.13.16-embed-amd64.zip | Complete 34-file vendor runtime, original download 11439094 bytes, SHA256 97dae5274cc54867065e8d5a3226e48c35017ed332a0fdb0e27d5b5821961297. |
| https://www.python.org/ftp/python/3.13.16/python-3.13.16-embed-amd64.zip.sigstore | Official bundle retained. Digest and signature mathematics checked with bundled certificate, thomas@python.org identity observed. Fulcio trust-chain/transparency policy validation was not performed. |
| https://www.python.org/ftp/python/3.13.16/python-3.13.16-embed-amd64.zip.spdx.json | Official SPDX retained; CPython 3.13.16, supplier Python Software Foundation, matching ZIP digest. SPDX NOASSERTION fields are preserved, not converted into license conclusions. |
| https://docs.python.org/3.13/using/windows.html#the-embeddable-package | Embedded runtime isolation, precompiled zipped standard library, no pip/TclTk/docs; host system ucrtbase.dll prerequisite. Pinned text retrieved from https://raw.githubusercontent.com/python/cpython/v3.13.16/Doc/using/windows.rst and included. |
| https://docs.python.org/3.13/library/sys_path_init.html#pth-files | Vendor ._pth controls module paths and isolation; registry/environment ignored. No ._pth modification. Supporting text in pinned Windows docs. |
| https://github.com/python/cpython/blob/v3.13.16/Lib/importlib/_bootstrap_external.py | SourceLoader.get_code catches OSError reading bytecode and compiles source; SourceFileLoader.set_data tolerates directory/write OSError. Pinned source retained as .py.txt documentation. This supports the zero-byte __pycache__ sentinel design; Windows package behavior still requires smoke validation. |
| https://docs.python.org/3.13/license.html | PSF and incorporated software notices; pinned Doc/license.rst and LICENSE retained alongside unchanged vendor LICENSE.txt. |
| https://learn.microsoft.com/en-us/windows/win32/fileio/reparse-points | Reparse points can redirect filesystem access; package checks ancestors and entries before writes/reads. Public source text was retrieved from MicrosoftDocs/win32/docs/desktop-src/FileIO/reparse-points.md. Existing unsafe paths are refused; hostile concurrent mutation is outside the boundary. |
| https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_execution_policies?view=powershell-5.1 | Execution policy and downloaded-file markings are preserved. Blocking is an acceptance result; no Bypass, Unblock or alternate script execution. Pinned platform version is Windows PowerShell 5.1; current official document source retrieved from MicrosoftDocs/PowerShell-Docs. |

This packaging turn changes no tested engine software and remediates no new
native failure. Earlier bounded version-specific known-issue searches and
diagnoses remain unchanged in app/REMEDIATION-0.1.1.md and 0.1.2.md. No new product
bug, runtime upgrade or causal explanation for either historical failure is
claimed. Signature certificate subjects are static metadata; Windows Authenticode
trust, revocation, SmartScreen and local policy behavior were not tested here.
