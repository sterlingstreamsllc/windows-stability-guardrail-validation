# Architecture and enforcement boundary

Maturity: interim / incremental engineering capability. Minimum future mission:
contain explicitly launched, trusted, finite local research batches while retaining
operator control and scientific evidence. Production IOC is NOT DEMONSTRATED.

## Mechanism

The controller creates a fresh named Windows Job Object, sets hard limits and reads
them back. It uses PROC_THREAD_ATTRIBUTE_JOB_LIST with CreateProcessW, plus suspended
startup, so assignment occurs during creation. It checks membership before resuming.
No separate create-then-assign gap is accepted. Attribute/assignment/readback failure
refuses launch. Parent-job incompatibility also refuses launch.

The controller alone owns a second kill-on-close job containing the watchdog. The
watchdog opens the workload job for query/termination and exchanges heartbeat events.
If the controller dies, closing its watchdog-job handle terminates the watchdog;
the last workload-job handle then closes and kills the workload. If the controller
stalls, the watchdog terminates the workload job. If the watchdog dies or stalls,
the controller terminates the workload job. The revised paths remain runtime unverified; the first baseline run is preserved as FAIL.

The emergency command opens the unique workload job recorded in runtime.json and
calls TerminateJobObject. It checks for zero remaining members. It never searches
for and kills processes by executable name. A concurrent status command temporarily
holds a job handle and can delay last-handle-close behavior; the direct emergency
termination path does not depend on last-handle closure.

## Default synthetic limits

| Control | Candidate implementation |
|---|---|
| Concurrent workload processes | Kernel hard cap 2 TOTAL, including root, helpers and Git |
| Git concurrency | Bounded by total <=2; with one Python root, only one child fits |
| Workload committed private memory | Kernel job cap 256 MiB, individual cap 192 MiB |
| Memory-denial fixture | 128 MiB job / 64 MiB process; attempts at most 128 MiB |
| CPU | Job CPU hard cap 20%; aggregate user CPU time 8 seconds |
| Wall duration | Controller 20 seconds, watchdog independent deadline +8 seconds |
| Watchdog | Separate job: 1 process, 128 MiB group / 96 MiB process, 5% CPU |
| Physical memory / commit | Warn below 8 GiB available; stop below 6 GiB available or commit headroom |
| Measurement hysteresis | Three consecutive critical samples; warning clears above 9 GiB |
| Failures / retries | Stop on first observed nonzero exit; zero automatic retries |
| Run admission | One controller per Windows interactive session; persisted 60-second inter-run backoff |
| Descendant creation rate | Trip if cumulative starts >10 per run / recent window; reactive |
| Logging | Three streams, each 256 KiB plus two backups; small fixed metadata files |

These values intentionally favor synthetic isolation over legitimate desktop
compatibility. Do not run the desktop in a two-process job: it has not been
qualified for that envelope. Increase no limit as an automatic response to failure.

## What is hard and what is reactive

Windows' active-process and private-commit limits are kernel restrictions. CPU limits
also survive controller stalls while the job exists. Memory allocation denial need
not itself kill the whole job; controller/watchdog intervention completes that policy.

Job Objects provide neither an exact per-image concurrency rule nor a hard
launches-per-minute rule for arbitrary descendants. The total cap is a conservative
way to bound Git concurrency, with substantial compatibility cost. Cumulative job
accounting catches short process bursts even if notifications are missed, but a
burst can exceed the rate target before the controller reacts. No strict rate claim
is made. A future broker must pre-admit every Git launch and disallow bypass paths
before it can claim an exact rate guarantee.

Completion-port notifications are best-effort. The controller reconciles active PIDs
and total starts, holds process handles to obtain exits, and trips if short-lived
children prevent complete attribution. PID-only ancestry and polling are never
treated as proof of job membership. The root's parent is logged; some child parent
IDs remain unavailable. The accounting counter is authoritative for aggregate starts.

The persistent OPEN_RUN marker is written before any launch. Controller crash, log
failure or incomplete termination readback cannot silently reopen admission. Reset
requires an explicit operator command while the singleton mutex is available and
no identified workload is active. Reset does not erase the 60-second backoff or
restart anything. Windows reboot does not close a persisted circuit automatically.

## Monitor scope and costs

GlobalMemoryStatusEx and GetPerformanceInfo provide physical available bytes and
system commit headroom. One main loop polls every 100 ms for job events and process
exits; expensive sample/state writes occur once per second. The watchdog samples
memory once per second and takes at most one native Toolhelp process snapshot per
five seconds for Defender observations. No PowerShell, WMI, Git or tasklist sampler
is launched. Event drains and state/line sizes are bounded.

Defender working set, private bytes and CPU deltas are best effort. Protected-process
access may fail, and is reported UNKNOWN/ACCESS_DENIED. No calibrated Defender
warning threshold is claimed. Disk queue depth, kernel pool attribution and file
creation rate are not implemented in this candidate. They remain acceptance targets
if mission measurements show they are necessary; do not substitute recursive scans.

The controller's own memory and CPU are not kernel-capped by this implementation.
Its bounded loops and small buffers need independent overhead measurement before
release. If both user-mode monitors are suspended, kernel limits remain but wall-time,
rate and headroom interventions may wait. Kernel/driver/storage failures remain outside
the safety claim. A single-user/session configuration is assumed; multiple sessions,
tampering with state files, external job-handle holders and privileged adversaries
are not contained by this prototype.

## Codex desktop and other bypasses

An already running desktop app and Git launched by that app are OUTSIDE this job.
A workload-only wrapper cannot contain them. MSIX activation, singleton redirection,
ShellExecute, COM, WMI, Task Scheduler, service brokers, elevation and externally
running daemons can create work outside ordinary child inheritance. No such launch
path is admitted by the synthetic-only interface.

The package does not attach to existing processes, inject, hook the OS, replace
Git, modify PATH, or set GIT_DIR=NUL. The latter is an unofficial reported workaround,
can disable reviews/changes/branch/commit features, may be bypassed by app activation,
and is not a supported containment mechanism.

The supported alternative to local desktop exposure is remote development while the
local app is fully closed, with later owner-launched local batches under a validated
controller. Actual desktop containment needs a separately authorized fresh-launch
architecture test; no desktop pilot is admissible until all relevant processes are
shown in the controlled job. Existing desktop coverage is a scoped IOC BLOCKER.

## Sources (retrieved 2026-10-21)

- [Microsoft Job Objects](https://learn.microsoft.com/en-us/windows/win32/procthread/job-objects):
  lifecycle, descendants, best-effort notifications, kill-on-last-handle close.
- [Atomic job assignment](https://devblogs.microsoft.com/oldnewthing/20230209-00/?p=107812):
  Windows 10 job-list startup attribute and the suspended-orphan gap.
- [Basic job limits](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_limit_information):
  process count, user CPU and memory semantics.
- [Extended job limits](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information):
  committed memory and peak accounting.
- [Job notifications](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_associate_completion_port):
  process and limit messages.
- [System performance data](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-performance_information):
  commit totals, limits and page size.

## 0.1.1 state and ownership changes (runtime unverified)

Retained handle exits are examined before queued PID notifications. Failed native
operations record operation/PID/winerror; an unknown/recycled identity fails closed.
Every in-job process, including any console helper, still counts. Explicit
DETACHED_PROCESS replaces CREATE_NO_WINDOW for synthetic native/fixture launches;
this is a console policy, not a claim of proved error-87 causation or a process exemption.

The admission mutex is still session-wide; state locks are per canonical package
path and held only for publication/reset transactions. Stop captures a run identity,
terminates that exact job and reads back zero members BEFORE trying the state lock.
If publication times out, it reports the termination observation and a nonzero error;
no CIRCUIT_OPEN success is claimed. OPEN_RUN remains fail-closed. Unique temporary
files prevent atomic-write pathname collisions. Epoch/run/job checks reject stale
stop/watchdog/controller publications after reset or new admission. Reset writes
RESETTING before clearing markers, so interrupted reset cannot silently reopen.

Controller cleanup attempts every release, preserves the first execution failure,
records secondary errors and waits on the retained watchdog process handle before
publishing CLOSED. Reset independently requires both identified jobs empty. A stuck
watchdog cannot be declared stopped merely because termination was requested.

The 0.1.0 cross-copy caveat remains: a session-wide live-controller mutex does not
share persisted trips/backoff between separate package directories. This prototype
is restricted to one trusted package directory and one session, without hostile
state-file tampering, external job-handle holders or privileged adversaries.
