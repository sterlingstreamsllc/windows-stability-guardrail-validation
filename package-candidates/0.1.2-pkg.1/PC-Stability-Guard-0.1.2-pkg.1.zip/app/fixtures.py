"""Finite synthetic fixtures. No Git installation or research file access."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

def write(value):
    path = Path(os.environ["PCSG_FIXTURE_RESULT"])
    data = json.dumps(value)
    if len(data) > 2048:
        raise ValueError("fixture size")
    path.write_text(data, encoding="utf-8")

def child_command(seconds="2"):
    return [sys.executable, "-I", str(Path(__file__).resolve()), "sleep", seconds]

def main():
    case = sys.argv[1]
    if case == "sleep":
        time.sleep(min(4, max(0, float(sys.argv[2]))))
        return 0
    if case == "normal":
        time.sleep(.5)
        write({"normal":True})
        return 0
    if case == "failure":
        write({"intentional_exit":7})
        return 7
    if case in ("hang","pressure","commit-pressure","controller-hang","watchdog-exit"):
        time.sleep(25)
        return 0
    if case == "memory-denial":
        blocks = []
        try:
            for i in range(16):  # absolute allocation ceiling 128 MiB
                blocks.append(bytearray(8*1024*1024))
        except MemoryError:
            del blocks
            write({"allocation_denied":True, "attempt_ceiling_mib":128})
            time.sleep(.3)
            return 42
        write({"allocation_denied":False})
        return 9
    if case in ("fanout","git-fanout"):
        children = []
        denied = False
        denial = None
        try:
            for i in range(3):  # finite, never a fork bomb
                cmd = child_command()
                if case == "git-fanout":
                    cmd = [os.environ["PCSG_SYNTHETIC_GIT"],"2000"]
                try:
                    children.append(subprocess.Popen(cmd, creationflags=0x8))
                except OSError as ex:
                    denied = True
                    denial = {"operation":"CreateProcessW", "winerror":ex.winerror}
                    break
            write({"launch_denied":denied, "denial":denial, "children_started":len(children)})
            for p in children:
                p.wait(timeout=5)
        finally:
            for p in children:
                if p.poll() is None:
                    p.terminate()
                    p.wait(timeout=3)
        return 27 if denied else 28
    if case == "breakaway":
        try:
            p = subprocess.Popen(child_command(".5"),
                                 creationflags=0x01000000 | 0x8)
        except OSError as e:
            write({"breakaway_denied":True, "winerror":e.winerror})
            return 0
        p.wait(timeout=3)
        write({"breakaway_denied":False})
        return 29
    if case == "parent-exit":
        p = subprocess.Popen(child_command("4"), creationflags=0x8)
        time.sleep(.5)
        write({"child_pid":p.pid, "intentional_parent_exit":True})
        return 0
    if case in ("churn","git-rate"):
        for i in range(12):
            cmd = child_command(".4")
            if case == "git-rate":
                cmd = [os.environ["PCSG_SYNTHETIC_GIT"],"400"]
            p = subprocess.Popen(cmd, creationflags=0x8)
            p.wait(timeout=3)
        write({"churn_finished":True})
        return 31
    raise ValueError("Unknown fixture")

if __name__ == "__main__":
    sys.exit(main())

