"""Static checks or bounded Windows-hosted synthetic tests. No production workloads."""
import ast
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import struct
import sys
import time
import uuid
import traceback
import zipfile

ROOT = Path(__file__).resolve().parent
# Only this reviewed source directory is added under isolated Python.
sys.path.insert(0, str(ROOT))
SOURCES = ("guard.py","native.py","fixtures.py","tests.py","pe_fixture.py")
COPY = SOURCES + ("config.json",)
CASES = ("normal","fanout","failure","memory-denial","hang","failed-launch",
         "parent-exit","breakaway","pressure","commit-pressure",
         "controller-hang","watchdog-exit","churn","git-fanout","git-rate",
         "emergency","controller-kill","admission",
         "concurrent-control","stop-under-state-lock","stale-stop-generation")
EXPECTED = {
 "fanout":{"JOB_LIMIT_OR_ABNORMAL_EXIT_3","PROCESS_FAILURE"},
 "failure":{"PROCESS_FAILURE"},
 "hang":{"WALL_TIMEOUT"},
 "failed-launch":{"NativeError"},
 "parent-exit":{"ROOT_EXIT_WITH_DESCENDANTS"},
 "pressure":{"SIMULATED_PHYSICAL_HEADROOM"},
 "commit-pressure":{"SIMULATED_COMMIT_HEADROOM"},
 "controller-hang":{"EXTERNAL_CIRCUIT_TRIP","WATCHDOG_EXIT","PROCESS_FAILURE",
                    "JOB_LIMIT_OR_ABNORMAL_EXIT_8"},
 "watchdog-exit":{"WATCHDOG_EXIT"},
 "churn":{"PROCESS_CREATION_RATE"},
 "git-fanout":{"JOB_LIMIT_OR_ABNORMAL_EXIT_3","PROCESS_FAILURE"},
 "git-rate":{"PROCESS_CREATION_RATE"},
 "emergency":{"EXTERNAL_CIRCUIT_TRIP","PROCESS_FAILURE","JOB_LIMIT_OR_ABNORMAL_EXIT_8"},
}

def static():
    global PF
    if not __debug__:
        raise RuntimeError("ASSERTIONS_MUST_REMAIN_ENABLED")
    receipt = {"scope":"STATIC_ONLY", "python":sys.version, "native_execution":"NOT_RUN",
               "production":"DISABLED", "files":{}}
    for name in SOURCES:
        data = (ROOT/name).read_bytes()
        ast.parse(data, filename=name)
        receipt["files"][name] = {"sha256":hashlib.sha256(data).hexdigest(),
                                 "bytes":len(data), "syntax":"PASS"}
    p = json.loads((ROOT/"config.json").read_text(encoding="utf-8"))
    assert p["release"] == "0.1.2-source-only"
    assert p["mode"] == "synthetic-only"
    assert p["max_active_processes"] == 2
    assert p["automatic_retries"] == 0
    assert p["stop_available_gib"] == p["stop_commit_gib"] == 6
    for key, value in {"max_job_memory_mib":256,"max_process_memory_mib":192,
                       "cpu_percent":20,"job_user_cpu_seconds":8,"wall_seconds":20,
                       "max_starts_per_60_seconds":10,"log_bytes":262144,
                       "log_backups":2}.items():
        assert p[key]==value, key
    # These checks are source assertions, not proof that Windows enforces them.
    text = (ROOT/"native.py").read_text(encoding="utf-8")
    assert "0x2000D" in text and "job.contains(pi.Process, int(pi.Pid))" in text
    assert "0x2000" in text and "CreateProcess" in text
    assert "BREAKAWAY_OK" in text  # comment declares omitted flags
    assert sys.version_info[:2] == (3,13)
    manifest = verify_manifest()
    import pe_fixture as PF  # pure byte inspection, no native imports or image execution
    # Check ctypes call arities without importing or executing Windows code.
    tree = ast.parse((ROOT/"native.py").read_bytes())
    arities = {}
    for node in tree.body:
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            call = node.value
            if isinstance(call.func, ast.Name) and call.func.id=="api":
                arities[node.targets[0].id] = len(call.args)-3
    calls = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in arities:
            assert len(node.args)==arities[node.func.id], (node.func.id, node.lineno)
            calls += 1
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id=="check":
            assert len(node.args)>=2, ("missing native operation context", node.lineno)
    guard_tree = ast.parse((ROOT/"guard.py").read_bytes())
    for node in ast.walk(guard_tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            f = node.func
            if isinstance(f.value, ast.Name) and f.value.id=="N" and f.attr in arities:
                assert len(node.args)==arities[f.attr], (f.attr, node.lineno)
                calls += 1
    workflow = (ROOT/".github/workflows/windows-synthetic.yml").read_text(encoding="utf-8")
    assert "on:\n  workflow_dispatch:" in workflow
    assert "runs-on: windows-latest" in workflow and "timeout-minutes: 10" in workflow
    assert "python-version: '3.13.16'" in workflow
    assert "timeout-minutes: 7" in workflow
    assert "/target:library /platform:x64" in workflow
    for action in ("actions/checkout@3d3c42e5aac5ba805825da76410c181273ba90b1",
                   "actions/setup-python@5fda3b95a4ea91299a34e894583c3862153e4b97",
                   "actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9"):
        assert action in workflow
    assert not any(trigger in workflow for trigger in ("  push:","  pull_request:","  schedule:"))
    assert len(CASES)==21 and CASES[0:3]==("normal","fanout","failure")
    fixture_checks = static_fixture_contract()
    receipt.update(manifest_files_verified=len(manifest["files"]),
                   native_call_arities_checked=calls, cases_planned=list(CASES),
                   dll_byte_contract_checks=fixture_checks)
    print(json.dumps(receipt, indent=2))
    return 0

def static_fixture_contract():
    # In-memory header specimen for parser checks only; no image is written/loaded.
    data = bytearray(1024)
    data[:2], data[128:132] = b"MZ", b"PE\0\0"
    def put(offset, value, size=4):
        struct.pack_into("<H" if size==2 else "<I", data, offset, value)
    put(60,128)
    for offset,value in ((132,0x8664),(134,1),(148,240),(150,0x2022),(152,0x20b)):
        put(offset,value,2)
    for offset,value in ((184,4096),(188,512),(208,8192),(212,512),(260,16),
                         (376,4096),(380,72),(400,512),(404,4096),(408,512),(412,512),
                         (512,72),(520,4168),(524,16),(528,1)):
        put(offset,value)
    data[584:588] = b"BSJB"
    assert PF.inspect_dll(data)["machine"]==0x8664
    # Each mutation must fail the specific structural contract, not a native call.
    mutations = ((0,b"NO"),(128,b"PX\0\0"),(132,b"\x4c\x01"),(152,b"\x0b\x01"),
                 (150,b"\x22\x00"),(134,b"\x61\x00"),(408,b"\xff\xff\xff\x7f"),
                 (532,b"\x01\0\0\0"),(584,b"NOPE"))
    for offset,value in mutations:
        changed = bytearray(data)
        changed[offset:offset+len(value)] = value
        try:
            PF.inspect_dll(changed)
        except ValueError as ex:
            assert str(ex).startswith("FAILED_LAUNCH_FIXTURE_")
        else:
            raise AssertionError(("fixture mutation accepted",offset))
    try:
        PF.inspect_dll(data[:400])
    except ValueError as ex:
        assert str(ex).startswith("FAILED_LAUNCH_FIXTURE_")
    else:
        raise AssertionError("truncated fixture accepted")
    return {"accepted_header_specimens":1, "rejected_mutations":len(mutations)+1,
            "native_execution":"NOT_RUN"}

def read(path):
    if path.stat().st_size > 32768:
        raise AssertionError("receipt oversized")
    return json.loads(path.read_text(encoding="utf-8"))

def cli(folder, *args):
    r = subprocess.run([sys.executable,"-I",str(folder/"guard.py"),*args],
                       cwd=folder, capture_output=True, text=True, timeout=8,
                       creationflags=0x8)
    if len(r.stdout)+len(r.stderr) > 32768:
        raise AssertionError("control output oversized")
    return r

def wait_runtime(folder, child):
    end = time.monotonic()+8
    while time.monotonic()<end:
        path = folder/"state"/"runtime.json"
        if path.exists():
            r = read(path)
            if r.get("root_pid") and r.get("heartbeat_utc"):
                return r
        if child.poll() is not None:
            raise AssertionError("controller exited before observation")
        time.sleep(.1)
    raise AssertionError("controller readiness timeout")

def event_rows(folder):
    out = []
    for path in sorted((folder/"state").glob("controller.jsonl*")):
        for line in path.read_text(encoding="utf-8").splitlines():
            if line:
                out.append(json.loads(line))
    return out

def verify_manifest():
    manifest = json.loads((ROOT/"SOURCE-MANIFEST.json").read_text(encoding="utf-8"))
    assert manifest["version"] == "0.1.2" and manifest["canonical_eol"] == "LF"
    required = set(COPY) | {".gitattributes",".github/workflows/windows-synthetic.yml",
                            "GitStub.cs","AGENTS.md","CLOUD-HANDOFF.md"}
    assert required <= manifest["files"].keys()
    for name, expected in manifest["files"].items():
        path = ROOT/name
        assert not Path(name).is_absolute() and ".." not in Path(name).parts
        data = path.read_bytes()
        # Original review/manifest history is preserved byte-for-byte.
        if not name.startswith("review-history/"):
            assert b"\r" not in data, name+": noncanonical EOL"
        assert hashlib.sha256(data).hexdigest()==expected["sha256"], name+": hash mismatch"
        assert len(data)==expected["bytes"], name+": byte count mismatch"
    return manifest

def bounded_write(path, value, limit=262144):
    data = json.dumps(value, indent=2).encode("utf-8")
    if len(data)>limit:
        raise RuntimeError("EVIDENCE_SIZE_LIMIT")
    path.write_bytes(data)

def fail(detail, ex, phase):
    error = {"phase":phase, "type":type(ex).__name__, "message":str(ex)[:2048],
             "traceback":traceback.format_exc()[-8192:],
             "cleanup_errors":getattr(ex,"cleanup_errors",[])}
    detail["status"] = "FAIL"
    if "failure" not in detail:
        detail["failure"] = error
    else:
        detail.setdefault("secondary_errors", []).append(error)

def identity():
    return {"os":platform.platform(), "python":sys.version,
            "python_version":platform.python_version(), "architecture":platform.machine(),
            "runner_image":os.environ.get("ImageVersion"), "runner_os":os.environ.get("ImageOS"),
            "commit":os.environ.get("GITHUB_SHA"), "run_id":os.environ.get("GITHUB_RUN_ID")}

def wait_file(path, proc=None, seconds=4):
    end = time.monotonic()+seconds
    while time.monotonic()<end:
        if path.exists():
            return
        if proc is not None and proc.poll() is not None:
            raise AssertionError("helper exited before barrier")
        time.sleep(.05)
    raise AssertionError("bounded barrier timeout")

def helper(folder, *args):
    return subprocess.Popen([sys.executable,"-I",str(folder/"guard.py"),*args],
                            cwd=folder, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, creationflags=0x8)

def helper_result(proc, seconds=8):
    out, err = proc.communicate(timeout=seconds)
    assert len(out)+len(err)<32768
    return {"exit_code":proc.returncode, "stdout":out, "stderr":err}

def retain(folder, evidence, case, stage="final"):
    # Raw generated bytes only, explicit allowlist, <=1 MiB per receipt bundle.
    names = ["runtime.json","breaker.json","watchdog-trip.json","admission.json"]
    names += [stream+".jsonl"+suffix for stream in ("controller","watchdog","operator")
              for suffix in ("", ".1", ".2")]
    items = [(folder/"state"/name, "state/"+name, 262144) for name in names]
    items += [(folder/"scratch"/name, "scratch/"+name, 32768) for name in (
        "fixture.json","ci-state-lock-held","ci-stop-captured","ci-stop-release",
        "ci-controller-stalled","launch-fixture.json")]
    items.append((folder/"config.json","config.json",32768))
    bundle = evidence/(case+"-receipts.zip")
    with zipfile.ZipFile(bundle, "a", compression=zipfile.ZIP_STORED) as archive:
        total = 22 + sum(info.file_size+256 for info in archive.infolist())
        for item, name, limit in items:
            if item.exists():
                assert item.stat().st_size<=limit
                data = item.read_bytes()
                total += len(data)+256
                assert total<=1048576, "receipt bundle exceeds 1 MiB"
                archive.writestr(stage+"/"+name,data)
    assert bundle.stat().st_size<=1048576

def check_limits(runtime, case):
    assert runtime.get("limits_read_back") is True
    limits = runtime["limits"]
    assert limits["active_limit"]==2
    assert limits["flags"]==0x8|0x200|0x100|0x2000|0x4
    assert limits["job_memory"]==(128 if case=="memory-denial" else 256)*1048576
    assert limits["process_memory"]==(64 if case=="memory-denial" else 192)*1048576
    assert limits["job_user_time"]==8*10000000
    assert limits["cpu_flags"]==5 and limits["cpu_rate"]==2000
    w = runtime["watchdog_limits"]
    assert w["active_limit"]==1 and w["job_memory"]==128*1048576
    assert w["process_memory"]==96*1048576 and w["cpu_rate"]==500
    assert w["flags"]==limits["flags"] and w["cpu_flags"]==5
    assert w["job_user_time"]==8*10000000

def execute_case(N, outer, stub, dll, dll_receipt, case, evidence):
    folder = outer/case
    proc = observer = outsider = None
    handles, watcher_handles, helpers = [], [], []
    detail = {"case":case, "status":"FAIL", "checks":[], "control_receipts":[]}
    bounded_write(evidence/(case+".json"), detail)
    try:
        folder.mkdir()
        for name in COPY:
            shutil.copyfile(ROOT/name, folder/name)
        p = read(folder/"config.json")
        p.update(baseline_profile="ci-synthetic",warn_available_gib=1,
                 stop_available_gib=.5,stop_commit_gib=.5,wall_seconds=8)
        (folder/"config.json").write_text(json.dumps(p), encoding="utf-8", newline="\n")
        env = dict(os.environ)
        env["PCSG_SYNTHETIC_GIT"] = str(stub)
        if case=="failed-launch":
            scratch = folder/"scratch"
            scratch.mkdir()
            assert dll.stat().st_size<=PF.MAX_BYTES
            data = dll.read_bytes()
            assert PF.inspect_dll(data)==dll_receipt["image"]
            (scratch/"failed-launch.dll").write_bytes(data)
            bounded_write(scratch/"launch-fixture.json",dll_receipt,32768)
        extras = ("concurrent-control","stop-under-state-lock","stale-stop-generation")
        fixture = "hang" if case in ("emergency","controller-kill",*extras) else (
                  "normal" if case=="admission" else case)
        if case=="concurrent-control":
            fixture = "controller-hang"
        proc = subprocess.Popen([sys.executable,"-I",str(folder/"guard.py"),"run",fixture],
                 cwd=folder, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                 text=True, creationflags=0x8)
        if case in ("emergency","controller-kill",*extras):
            live = wait_runtime(folder,proc)
            observer = N.Job(live["job"])
            for pid in observer.pids():
                h = N.process_handle(pid)
                handles.append(h)  # immediate ownership, even if contains fails
                assert observer.contains(h, pid)
            assert handles
            observer.close()
            observer = None
            watcher = N.process_handle(live["watchdog_pid"])
            watcher_handles.append(watcher)
            observer = N.Job(live["watchdog_job"])
            assert observer.contains(watcher, live["watchdog_pid"])
            observer.close()
            observer = None
            if case=="controller-kill":
                proc.terminate()
            elif case=="emergency":
                outsider = subprocess.Popen(
                    [sys.executable,"-I",str(folder/"fixtures.py"),"sleep","4"],
                    creationflags=0x8)
                stopped = cli(folder,"stop")
                detail["control_receipts"].append({"stop":stopped.stdout, "exit_code":stopped.returncode})
                assert stopped.returncode==0 and "SUPERVISED_JOB_EMPTY; CIRCUIT_OPEN" in stopped.stdout
                assert outsider.poll() is None
                detail["checks"].append("unrelated_synthetic_process_survived")
            elif case=="concurrent-control":
                # Both contenders overlap a live controller; neither may launch/reset.
                contenders = [helper(folder,"run","normal"), helper(folder,"reset","--owner-reset")]
                helpers.extend(contenders)
                for contender in contenders:
                    r = helper_result(contender)
                    detail["control_receipts"].append(r)
                    assert r["exit_code"]==30 and "ANOTHER_CONTROLLER_OR_RESET_IS_ACTIVE" in r["stdout"]
                wait_file(folder/"scratch"/"ci-controller-stalled",proc,4)
                stops = [helper(folder,"stop"),helper(folder,"stop")]
                helpers.extend(stops)
                for stop in stops:
                    r = helper_result(stop)
                    detail["control_receipts"].append(r)
                    assert r["exit_code"]==0 and "SUPERVISED_JOB_EMPTY; CIRCUIT_OPEN" in r["stdout"]
                detail["checks"].append("concurrent_admission_reset_refused_and_stalled_controller_stopped")
            elif case=="stop-under-state-lock":
                locker = helper(folder,"_ci_hold_state")
                helpers.append(locker)
                wait_file(folder/"scratch"/"ci-state-lock-held",locker)
                stop = helper(folder,"stop")
                helpers.append(stop)
                # Direct termination must precede the unavailable publication lock.
                for h in handles:
                    N.wait_exit(h,1000)
                r = helper_result(stop)
                detail["control_receipts"].append(r)
                assert r["exit_code"]==30
                assert "SUPERVISED_JOB_EMPTY; CIRCUIT_PUBLICATION_PENDING" in r["stdout"]
                assert "ANOTHER_CONTROLLER_OR_RESET_IS_ACTIVE" in r["stdout"]
                assert helper_result(locker)["exit_code"]==0
                detail["checks"].append("emergency_kill_does_not_wait_for_state_lock")
            elif case=="stale-stop-generation":
                stale = helper(folder,"stop","--ci-stop-barrier")
                helpers.append(stale)
                wait_file(folder/"scratch"/"ci-stop-captured",stale)
                assert cli(folder,"stop").returncode==0
                output,error = proc.communicate(timeout=8)
                detail.update(controller_output=output, controller_stderr=error)
                retain(folder,evidence,case,"before-reset")
                assert cli(folder,"reset","--owner-reset").returncode==0
                reset_state = read(folder/"state"/"runtime.json")
                (folder/"scratch"/"ci-stop-release").write_text("release",encoding="utf-8")
                r = helper_result(stale)
                detail["control_receipts"].append(r)
                assert r["exit_code"]==30 and "STALE_RUN_TRIP_REFUSED" in r["stdout"]
                assert read(folder/"state"/"runtime.json")==reset_state
                assert not (folder/"state"/"breaker.json").exists()
                detail["checks"].append("stale_stop_cannot_retrip_reset_epoch")
        output,error = proc.communicate(timeout=25)
        detail.update(exit_code=proc.returncode, controller_output=output, controller_stderr=error)
        assert len(output)+len(error)<32768
        runtime = read(folder/"state"/"runtime.json")
        detail["runtime"] = runtime
        rows = event_rows(folder)
        # Termination is asynchronous. Observe the already-retained handles before
        # job emptiness, especially after controller-kill closes both job owners.
        for h in handles+watcher_handles:
            N.wait_exit(h,3000)
        detail["retained_exits_confirmed"] = {"workload":len(handles),
                                             "watchdog":len(watcher_handles)}
        try:
            observer = N.Job(runtime["job"])
        except OSError as ex:
            assert ex.winerror==2
        else:
            try:
                assert observer.accounting()["active"]==0
            except BaseException as ex:
                ex.cleanup_errors = N.cleanup([("CloseObserver", observer.close)])
                observer = None
                raise
            else:
                observer.close()
                observer = None
        observed = [row["active"] for row in rows if row["event"]=="sample"]
        assert not observed or max(observed)<=2
        if case not in ("controller-kill","stop-under-state-lock"):
            check_limits(runtime,case)
            assert runtime["final_accounting"]["active"]==0
            assert runtime["watchdog_exit_confirmed"] is True
            assert runtime["process_observation"]=="COMPLETE"
            if case!="failed-launch":
                assert not runtime.get("observability_error")
            assert not runtime.get("cleanup_errors")
        fpath = folder/"scratch"/"fixture.json"
        f = read(fpath) if fpath.exists() else {}
        if case in ("normal","breakaway","admission"):
            assert proc.returncode==0 and runtime["state"]=="CLOSED"
            if case=="breakaway":
                assert f.get("breakaway_denied") is True and f.get("winerror")==5
            else:
                assert f.get("normal") is True
        elif case=="memory-denial":
            assert proc.returncode==20 and runtime["state"]=="OPEN"
            assert f.get("allocation_denied") is True or runtime.get("reason") in (
                "JOB_LIMIT_OR_ABNORMAL_EXIT_9","JOB_LIMIT_OR_ABNORMAL_EXIT_10")
            assert runtime["final_peak_job_commit"]<=128*1048576
        elif case=="controller-kill":
            assert handles and runtime["state"]=="OPEN_RUN"
        elif case in extras:
            assert proc.returncode==20
            if case=="stop-under-state-lock":
                check_limits(runtime,case)
                assert runtime["state"] in ("OPEN", "OPEN_RUN")
                final = json.loads(output.splitlines()[-1])
                assert final["state"]=="OPEN"
                assert final["reason"] in ("PROCESS_FAILURE","EXTERNAL_CIRCUIT_TRIP",
                                            "ANOTHER_CONTROLLER_OR_RESET_IS_ACTIVE")
                if runtime["state"]=="OPEN_RUN":
                    assert any(e.get("reason")=="ANOTHER_CONTROLLER_OR_RESET_IS_ACTIVE"
                               for e in final["cleanup_errors"])
                # Retained kernel process handles, not stale files, prove both exits.
                assert watcher_handles and handles
            else:
                assert runtime["state"]==("CLOSED" if case=="stale-stop-generation" else "OPEN")
        else:
            assert proc.returncode==20 and runtime["state"]=="OPEN"
            assert runtime["reason"] in EXPECTED[case], runtime["reason"]
        if case=="failure":
            assert f.get("intentional_exit")==7
            assert any(row["event"]=="process-exit" and row.get("pid")==runtime["root_pid"]
                       and row.get("code")==7 for row in rows)
            assert {"pid":runtime["root_pid"],"code":7} in runtime["observed_failures"]
        if case in ("fanout","git-fanout"):
            assert ((f.get("launch_denied") is True and f.get("children_started")==1
                     and f.get("denial")=={"operation":"CreateProcessW","winerror":1816}
                     and runtime["final_accounting"]["total"]==2) or
                    any(row["event"]=="job-notification" and row.get("message")==3 for row in rows))
        if case=="failed-launch":
            first = runtime["first_error"]
            assert first=={"type":"NativeError","operation":"CreateProcessW","pid":None,"winerror":193}
            assert runtime["observability_error"]==first
            assert runtime["final_accounting"]=={"total":0,"active":0,"terminated":0,"cpu":0}
            assert runtime["final_peak_job_commit"]==0
            assert runtime["root_created"] is False and runtime["root_resumed"] is False
            assert "root_pid" not in runtime
            assert not any(row["event"] in ("root-start","root-resume","process-exit",
                                           "child-observed","child-reconciled") for row in rows)
            attempts = [row for row in rows if row["event"]=="failed-launch-attempt"]
            assert len(attempts)==1 and attempts[0]["fixture"]==dll_receipt["image"]
            assert runtime["failed_launch_fixture"]==dll_receipt
            checked_dll = folder/"scratch"/"failed-launch.dll"
            assert checked_dll.stat().st_size<=PF.MAX_BYTES
            assert PF.inspect_dll(checked_dll.read_bytes())==dll_receipt["image"]
            detail["failed_launch_fixture"] = dll_receipt
            assert runtime["watchdog_exit_confirmed"] is True
            assert not runtime["cleanup_errors"]
        if case=="controller-hang":
            assert read(folder/"state"/"watchdog-trip.json")["reason"]=="CONTROLLER_HEARTBEAT_LOST"
        if case.startswith("git-"):
            assert any(row.get("executable")=="git.exe" for row in rows)
        if case not in ("normal","breakaway","admission","stale-stop-generation"):
            repeat = cli(folder,"run","normal")
            detail["control_receipts"].append({"operation":"circuit-refusal",
                "exit_code":repeat.returncode,"stdout":repeat.stdout,"stderr":repeat.stderr})
            assert repeat.returncode!=0 and "CIRCUIT_OPEN_OWNER_RESET_REQUIRED" in repeat.stdout
            if case=="failed-launch":
                refusal = json.loads(repeat.stdout.splitlines()[-1])
                assert repeat.returncode==20 and refusal["state"]=="OPEN"
                assert refusal["reason"]=="CIRCUIT_OPEN_OWNER_RESET_REQUIRED"
                assert refusal["cleanup_errors"]==[]
                assert read(folder/"state"/"runtime.json")==runtime
            retain(folder,evidence,case,"before-reset")
            reset = cli(folder,"reset","--owner-reset")
            detail["control_receipts"].append({"operation":"disposable-reset",
                "exit_code":reset.returncode,"stdout":reset.stdout,"stderr":reset.stderr})
            assert reset.returncode==0
            reset_state = read(folder/"state"/"runtime.json")
            assert reset_state["state"]=="CLOSED"
            if case=="failed-launch":
                assert reset_state["epoch"]!=runtime["epoch"]
                assert reset_state["run_id"]==runtime["run_id"]
                assert reset_state["final_accounting"]==runtime["final_accounting"]
                assert not (folder/"state"/"breaker.json").exists()
                assert not (folder/"state"/"watchdog-trip.json").exists()
                detail["disposable_reset"] = {"state":reset_state["state"],
                                             "epoch":reset_state["epoch"]}
            detail["checks"].append("circuit_refusal_and_explicit_disposable_reset")
        if case=="admission":
            retain(folder,evidence,case,"before-backoff")
            repeat = cli(folder,"run","normal")
            assert repeat.returncode==20 and "ADMISSION_BACKOFF_60_SECONDS" in repeat.stdout
        detail["status"] = "PASS"
    except BaseException as ex:
        fail(detail,ex,"case")
    finally:
        # Every cleanup and evidence operation is isolated; first failure stays first.
        def attempt(phase, action):
            try:
                action()
            except BaseException as ex:
                fail(detail,ex,phase)
        if proc is not None and proc.poll() is None:
            attempt("emergency-cleanup", lambda:cli(folder,"stop"))
            if proc.poll() is None:
                attempt("terminate-controller", proc.terminate)
                attempt("wait-controller", lambda:proc.wait(timeout=5))
        if proc is not None:
            def capture():
                out, err = proc.communicate(timeout=3)
                assert len(out)+len(err)<32768
                detail.setdefault("controller_output",out)
                detail.setdefault("controller_stderr",err)
                detail.setdefault("exit_code",proc.returncode)
            attempt("capture-controller",capture)
        for h in handles+watcher_handles:
            attempt("close-observer-process",lambda h=h:N.close(h))
        if observer:
            attempt("close-observer-job",observer.close)
        for child in helpers:
            if child.poll() is None:
                attempt("wait-finite-helper",lambda child=child:child.wait(timeout=5))
                if child.poll() is None:
                    attempt("terminate-helper",child.terminate)
                    attempt("wait-terminated-helper",lambda child=child:child.wait(timeout=3))
        if outsider:
            attempt("wait-finite-outsider",lambda:outsider.wait(timeout=5))
        attempt("retain-receipts",lambda:retain(folder,evidence,case))
        attempt("write-case-evidence",lambda:bounded_write(evidence/(case+".json"),detail))
        print(json.dumps({"case":case,"status":detail["status"],"failure":detail.get("failure")}))
    return detail

def windows():
    global PF
    if not (os.name=="nt" and os.environ.get("GITHUB_ACTIONS")=="true"
            and os.environ.get("RUNNER_ENVIRONMENT")=="github-hosted"):
        raise RuntimeError("Only an approved GitHub-hosted Windows workflow may run this suite")
    evidence = ROOT/"ci-evidence"
    evidence.mkdir(exist_ok=True)
    start = time.monotonic()
    results = []
    summary = {"scope":"HOSTED_WINDOWS_SYNTHETIC_ONLY", "production":"DISABLED",
               **identity(), "cases_planned":list(CASES), "cases_executed":0, "all_pass":False}
    setup = {"status":"FAIL", "phase":"initializing"}
    try:
        bounded_write(evidence/"summary.json",summary)
        bounded_write(evidence/"setup.json",setup)
        manifest = verify_manifest()
        summary["source_hashes"] = {s:manifest["files"][s]["sha256"] for s in COPY}
        assert platform.python_version()=="3.13.16", "unreviewed hosted Python version"
        assert platform.machine().upper()=="AMD64", "fixture requires native AMD64 host"
        sys.path.insert(0, str(ROOT))
        import pe_fixture as PF
        import native as N
        sizes = {"Basic":64,"Extended":144,"Startup":104,"StartupEx":112,
                 "Accounting":48,"ProcessInfo":24,"IO":48,"Associate":16,"Cpu":8,
                 "MemoryStatus":64,"Performance":104,"Entry":568,"Counters":80}
        setup["abi_sizes"] = {name:N.C.sizeof(getattr(N,name)) for name in sizes}
        assert setup["abi_sizes"]==sizes
        assert N.Basic.MinWS.offset==24 and N.Extended.ProcessMemory.offset==112
        assert N.StartupEx.Attributes.offset==104 and N.Entry.Exe.offset==44
        outer = Path(os.environ["RUNNER_TEMP"]).resolve()/("pcsg-"+uuid.uuid4().hex)
        outer.mkdir()
        stub = Path(os.environ["PCSG_TEST_GIT"]).resolve()
        assert stub.is_file() and stub.name.lower()=="git.exe"
        summary["fixture_executable_sha256"] = hashlib.sha256(stub.read_bytes()).hexdigest()
        summary["python_executable_sha256"] = hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest()
        dll = Path(os.environ["PCSG_TEST_DLL"]).resolve()
        assert dll.is_file() and dll.name=="failed-launch.dll" and dll.stat().st_size<=PF.MAX_BYTES
        image = PF.inspect_dll(dll.read_bytes())
        build = read(evidence/"fixture-build.json")
        source_hash = manifest["files"]["GitStub.cs"]["sha256"]
        assert build["source_sha256"].lower()==source_hash
        assert build["fixture_sha256"].lower()==summary["fixture_executable_sha256"]
        assert build["failed_launch"]["sha256"].lower()==image["sha256"]
        assert build["failed_launch"]["options"]==["/nologo","/target:library","/platform:x64"]
        compiler = Path(build["compiler"])
        assert hashlib.sha256(compiler.read_bytes()).hexdigest()==build["compiler_sha256"].lower()
        dll_receipt = {"image":image, "source":"GitStub.cs", "source_sha256":source_hash,
                       "compiler_sha256":build["compiler_sha256"].lower(),
                       "compiler_options":build["failed_launch"]["options"]}
        summary["failed_launch_fixture"] = dll_receipt
        setup["failed_launch_fixture"] = dll_receipt
        setup.update(status="PASS",phase="ready")
        bounded_write(evidence/"setup.json",setup)
        for case in CASES:
            if time.monotonic()-start>360:
                raise RuntimeError("SUITE_ADMISSION_DEADLINE")
            result = execute_case(N,outer,stub,dll,dll_receipt,case,evidence)
            results.append(result)
            summary["cases_executed"] = len(results)
            bounded_write(evidence/"summary.json",summary)
            if result["status"]!="PASS":
                break
        summary["all_pass"] = len(results)==len(CASES) and all(r["status"]=="PASS" for r in results)
    except BaseException as ex:
        fail(summary,ex,"suite-setup-or-finalization")
        if setup["status"]!="PASS":
            fail(setup,ex,"setup")
    finally:
        summary.update(elapsed_seconds=time.monotonic()-start,
                       cases_unexecuted=list(CASES[len(results):]))
        for name, value in (("setup.json",setup),("summary.json",summary)):
            try:
                bounded_write(evidence/name,value)
            except BaseException as ex:
                summary["all_pass"] = False
                print(json.dumps({"evidence_write_failure":name,"type":type(ex).__name__}))
        print(json.dumps(summary,indent=2))
    return 0 if summary["all_pass"] else 1

if __name__=="__main__":
    if sys.argv[1:]==["--static-only"]:
        sys.exit(static())
    if sys.argv[1:]==["--hosted-windows"]:
        sys.exit(windows())
    raise SystemExit("Choose --static-only or approved --hosted-windows")
