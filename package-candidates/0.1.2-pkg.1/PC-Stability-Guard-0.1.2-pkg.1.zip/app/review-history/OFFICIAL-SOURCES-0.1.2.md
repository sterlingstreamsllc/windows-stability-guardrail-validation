# Bounded official check before 0.1.2 remediation

Date: 2026-10-21 UTC. Hosted Cloud, TLS-verified HTTPS through its configured
proxy. No runtime/product upgrade or native execution. Only public official
documentation, targeted issue searches and release notes were fetched; no other
repository was checked out. This is a bounded check, not an exhaustive issue search.

Queries on the official GitHub issue pages returned "No results":

| Official issue scope | Query (is:issue prefix) | Applicability |
|---|---|---|
| [python/cpython](https://github.com/python/cpython/issues?q=is%3Aissue+%223.13.16%22+%22CreateProcess%22+%22216%22) | "3.13.16" "CreateProcess" "216" | No exact pinned Python match found; native.py calls kernel32 directly through ctypes. |
| [actions/runner-images](https://github.com/actions/runner-images/issues?q=is%3Aissue+%2220261007.264%22+%22216%22) | "20261007.264" "216" | No exact image/error match found. |
| [MicrosoftDocs/sdk-api](https://github.com/MicrosoftDocs/sdk-api/issues?q=is%3Aissue+%22CreateProcessW%22+%22ERROR_EXE_MACHINE_TYPE_MISMATCH%22) | "CreateProcessW" "ERROR_EXE_MACHINE_TYPE_MISMATCH" | No exact documented API issue found; documentation issues are not a complete Windows product tracker. |

Release/changelog check:

- [CPython 3.13.16 NEWS](https://github.com/python/cpython/blob/v3.13.16/Misc/NEWS.d/3.13.16.rst),
  retrieved from its raw URL. Inspected Windows sections and searched
  CreateProcess, EXE_MACHINE, BAD_EXE, 216, 193, subprocess and ctypes. No applicable
  loader-failure fix found. Console/stdio, callback and static-interpreter import
  entries do not explain this fixture's CreateProcessW result. Initial legacy
  `v3.13.16/Misc/NEWS` URL was 404; the correct NEWS.d release file returned 200.
- [Runner image win25-vs2026/20261007.264](https://github.com/actions/runner-images/releases/tag/win25-vs2026%2F20261007.264),
  HTTP 200. Release identifies image 20261007.264.1 and cached Python 3.13.16.
  Reviewed release changes; no applicable 193/216/CreateProcess loader fix found.
  Installed-tool changes are not evidence of the old fixture's failure cause.

API/format troubleshooting references, reviewed before code edits:

1. [System error codes 0-499](https://learn.microsoft.com/en-us/windows/win32/debug/system-error-codes--0-499-):
   193 is ERROR_BAD_EXE_FORMAT; 216 is ERROR_EXE_MACHINE_TYPE_MISMATCH. Labels do
   not prove why the old 19-byte text selected 216.
2. [PE format](https://learn.microsoft.com/en-us/windows/win32/debug/pe-format):
   DOS offset 0x3c locates PE signature; COFF identifies Machine; AMD64=0x8664;
   PE32+=0x20b; IMAGE_FILE_DLL=0x2000 denotes images that cannot run directly.
   Section/header sizes and file/RVA bounds support independent byte inspection.
3. [GetBinaryTypeW](https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-getbinarytypew):
   explicitly specifies ERROR_BAD_EXE_FORMAT for a DLL. This is corroborating
   fixture semantics for a DIFFERENT API, not a guarantee about CreateProcessW.
   The candidate does not substitute this API for the actual launch assertion.
4. [CreateProcessW](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw):
   failure returns zero, with GetLastError providing attribution; successful return
   precedes initialization. The DLL must fail at CreateProcessW itself, not return
   a process that later exits. No retrieved primary source universally guarantees
   exact CreateProcessW=193 for this DLL. That remains the prospective test target.
5. [TerminateProcess](https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-terminateprocess),
   retrieved again during the second source pass, before the downstream ordering
   edit: termination from another process is asynchronous; WaitForSingleObject on
   the process handle confirms exit. This supports moving the harness's existing
   retained-handle waits ahead of its job-empty assertion, without new waits,
   deadline changes, weaker assertions or additional launch attempts.

Microsoft pages were retrieved through the official MicrosoftDocs raw mirrors
(the direct Learn host is outside the environment's configured allowlist):

| Mirror path, raw.githubusercontent.com | Retrieved bytes SHA256 |
|---|---|
| MicrosoftDocs/win32/docs/desktop-src/Debug/system-error-codes--0-499-.md | 01ee28615b6cb98f5e043a80dd48a534a9bb55d5bc75c279953a3423d838d12d |
| MicrosoftDocs/win32/docs/desktop-src/Debug/pe-format.md | b17271a341f9b6e3204cf3f04ed905c25c03fd4cadb7a57bd4aaf38cf56a2fe0 |
| MicrosoftDocs/sdk-api/docs/sdk-api-src/content/winbase/nf-winbase-getbinarytypew.md | 0427e9bdaaf45123a419e8b422992f9f0413925a9129cb7d9bbc953d67339266 |
| MicrosoftDocs/sdk-api/docs/sdk-api-src/content/processthreadsapi/nf-processthreadsapi-createprocessw.md | 611ec4cb3c30018ac7a31532395339ff3da850c4da7ad4197f9d6a7a5e5fff85 |
| MicrosoftDocs/sdk-api/docs/sdk-api-src/content/processthreadsapi/nf-processthreadsapi-terminateprocess.md | eb08e9fcf4166a9e0b2907e707a0bc25ea75b831ea0ce4f1992a85b542f720a0 |
| python/cpython/v3.13.16/Misc/NEWS.d/3.13.16.rst | 0d3e52811637771c2cbdd5f8693e288ae4efb1d240fcdd401494585323274859 |

Conclusion: fix the underspecified fixture/contract in this source. No confirmed
upstream bug or version update is a justified remedy. The new DLL uses the same
finite C# source and installed compiler, explicitly /target:library /platform:x64.
It avoids a foreign-machine assumption and retains exact error 193, without
accepting 216 or other failures. Build timestamps may vary; exact output bytes
are hashed per run rather than claimed byte-identical across builds.
