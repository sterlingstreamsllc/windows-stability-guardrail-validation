# 0.1.2 source-only failed-launch remediation

Parent/tested source: 255f256ca6525ef190cf8069396f67ae448b57c8 (0.1.1).
Original baseline: c8e382ec3187f68da2a432cec58d61facd94c50b (0.1.0).
Target: codex/fix-failed-launch-0-1-2. Main, both historical commits, the 0.1.1
branch, original review, original remediation report and first-run history remain
preserved. SECOND-RUN.md records owner-supplied run metadata as documentation;
both historical hosted runs remain FAIL. No raw artifact was uploaded by Cloud.

Environment reconfirmed before shell work: provider=cloud, observed_phase=running,
observations_current=true, environment ID
ccarenv_b64_Y2NhcmVudl81YmYwYzEyYjA0YjA4MTkxOWQxOGNlZGUwY2VhNDgwYw.
Work was confined to /workspace/windows-stability-guardrail and temporary review
receipts/public documentation. No other checkout, subagent, workstation executor,
host drive, credentials extraction, Windows execution, workload execution,
installation or workflow dispatch/retry was used.

## Diagnosis and narrow correction

The old 19-byte plain-text file had no explicit PE machine/format contract. Its
CreateProcessW result 216 contradicted the test's exact 193 assertion; cause of
that particular loader choice remains unknown. The observed OPEN circuit, zero
job totals and stopped watchdog do not convert the failed assertion into PASS.
The earlier error-87 failure case passed with exact exit 7 in run two, without
establishing historical causation. OFFICIAL-SOURCES-0.1.2.md records the dated
bounded official issue/release/changelog/API check completed before edits. No
applicable pinned-version product fix was found; no version is upgraded.

The fixture now uses the existing finite GitStub.cs and the same existing Windows
C# compiler, with /target:library /platform:x64. No foreign architecture, new source
payload, runtime dependency or arbitrary-error allowance is introduced. The source
is unchanged and contains only bounded sleep and return. Compilation produces a
DLL, which Microsoft documents as an image that cannot run directly. GetBinaryTypeW
documents error 193 for DLLs; CreateProcessW is a different API, and its exact 193
result is still a prospective hosted assertion, not established universal proof.
The suite does not replace CreateProcessW with a weaker preflight observation.

pe_fixture.py only inspects bytes. It checks file size <=1 MiB, DOS/PE signatures,
bounded offsets, AMD64 0x8664, PE32+ 0x20b, executable/DLL flags, optional-header and
section-table extents, alignment, nonoverlapping raw/RVA section extents, directory
bounds, CLR metadata signature/extent, IL-only x64 and absent managed entry point.
It is a narrow inspector for this compiler output, not a general PE verifier or a
loader emulator. Compiler timestamp bytes may vary; the run records exact source,
compiler and output SHA256s and compiler options. Harness setup validates provenance;
controller and harness re-read the copied fixture and compare its hash/structure.
Receipts include the exact <=4 KiB PE headers and 72-byte CLR header as hex, so
their machine, format, DLL flags and extents can be inspected independently.
Only text source/docs are uploaded; generated DLL/EXE files stay in runner temp.

The actual workload launch still uses native.py's suspended CreateProcessW with
atomic Job Object assignment. Only exact NativeError/CreateProcessW/193/null PID
can pass. A successful return is immediately treated as a failure while the process
is still suspended, retaining process/thread ownership for termination and closure.
No root resume is allowed in that branch. Errors from fixture inspection, API
attributes, job membership, watchdog, readback or cleanup cannot satisfy the case.

## Acceptance and evidence

The failed-launch case now also requires:

- Exactly one hash/structure-attributed attempt; no root PID, successful start,
  resume, child observation or process-exit event.
- Final workload total=active=terminated=CPU=peak commit=0, complete attribution,
  original workload/watchdog hard-limit readbacks, confirmed watchdog exit and no
  cleanup errors. The expected observability_error must equal the exact first error.
- OPEN/exit 20; a second admission specifically refuses the open circuit with
  exit 20, no cleanup errors and unchanged runtime. An explicit disposable reset
  succeeds, changes epoch, preserves run identity/accounting and clears trip files.
- Source/compiler/options/output/parsed-image receipts in workflow build, setup,
  summary, runtime and failed-case evidence. Raw launch-fixture.json is allowlisted
  in the existing bounded receipt ZIP. Circuit-refusal/reset command receipts are
  retained, including pre-reset snapshots. No raw DLL upload is needed for the
  source handoff; native build/output bytes remain unverified until the hosted run.

All 21 cases remain in the same order, with first-failure stop and no retries.
The five original review remediations are preserved: watchdog wait-before-final,
state/reset/run-identity serialization with emergency kill ahead of locks,
exception-safe native ownership with first-error preservation, exact exit 7 and
breakaway denial/concurrency/limit acceptance, and bounded failure evidence.
native.py, fixtures.py, GitStub.cs and old review-history files are unchanged.

## Static receipt and dedicated second review

The sole executable repository check is `python -I tests.py --static-only`, with
existing /usr/bin/python3.13 resolving to 3.13.5. No installation/update is needed.
It AST-parses five sources, verifies manifest hashes/LF, original policy and action
pins, checks native-call arities, and inspects one small in-memory PE header
specimen plus ten rejecting mutations. These bytes are never written as an image,
loaded or executed. guard.py, native.py and fixture workloads are not imported by
the static path. The exact final receipt is delivered outside the source manifest
to avoid circular self-hashing; final commit/tree/file hashes accompany it.

The dedicated second source pass covers the edited workflow/fixture/provenance
path, PE offsets and bounds, native launch ownership on failure and unexpected
success, first-error attribution, watchdog-before-final ordering, state identities,
exact assertions, evidence finally paths, and every downstream case. It is a
second pass by the same reviewer, without an independent agent or runtime proof.

One concrete downstream ordering defect was corrected: the harness checked job
emptiness before waiting on its already-retained workload/watchdog process handles.
After controller-kill, job-owner closures and process termination can still be
completing. Microsoft's asynchronous-termination guidance was reviewed before the
edit. The same existing three-second handle waits now precede readback; the same
zero-active assertion and exact error-2 missing-job observation remain. No extra
poll, wait, launch, retry, accepted error or deadline extension was added. Receipt
counts record which retained exits were confirmed. This is the only downstream
control-flow change beyond failed-launch preparation and additional receipts.

Reviewed the remaining cases in order: parent-exit requires a live descendant,
breakaway requires error 5, injected pressure preserves sampling/hysteresis,
controller-hang requires the watchdog heartbeat-loss marker, watchdog-exit requires
its specific trip, churn/Git cases retain finite starts and observed Git identity,
emergency retains an unrelated finite process, controller-kill uses retained
handles, admission retains backoff, and all three concurrency cases retain their
barriers, epoch assertions and fail-closed lock semantics. No other concrete source
blocker was identified; their timing and native observations remain unverified.

Second source-review status: COMPLETE after the ordering edit and final re-read.
Static disposition: PASS on Python 3.13.5; five Python sources parsed, 30 manifest
entries verified, 42 native-call arities checked, one header specimen accepted and
ten malformed variants rejected. git diff --check passed. The final static command
is repeated after the report/manifest are finalized; its exact receipt/hash is in
the handoff. No unresolved source blocker to the bounded diagnostic run was found.

## Resource bounds and remaining native gaps

Policy values are unchanged: two TOTAL in-job processes (including system helpers),
<=256 MiB workload job /192 MiB per process, 20% CPU, eight seconds job user CPU,
20 seconds wall (eight in CI copies), zero retries. Watchdog remains one process,
128/96 MiB and 5% CPU with independent heartbeat/absolute deadline. The new DLL
uses zero workload processes on the required path. One additional finite compiler
invocation occurs before the suite under the existing ten-minute job timeout.
The byte inspector uses <=1 MiB input, <=4 KiB retained headers, <=96 sections and 16 directories, with
bounded loops and no native calls or dynamic loading.

All fixtures remain finite: allocation <=128 MiB, fanout three attempts, churn
twelve sequential children, synthetic Git sleeps <=four seconds, CI control hooks
have their original bounds. There are no research or real Git workloads. The
six-minute between-case admission, seven-minute suite and ten-minute job bounds
are intact. Evidence stays <=1 MiB per bundle, <=256 KiB per case, <=160 files and
32 MiB total; the new receipt is small and still subject to those unchanged caps.
Compiler/controller overhead is not newly measured or claimed to be job-capped.

Remaining gaps: actual compiler output/parser compatibility; exact CreateProcessW
193 for that DLL on the resolved hosted image; all 21 cases for 0.1.2, including
the 15 never reached in run two; native ABI/loader/accounting, notification timing,
watchdog/stop/reset races and cleanup behavior on this revision. windows-latest
still resolves its image, which receipts must identify. Python stays pinned to
3.13.16 x64 and all three action SHAs stay fixed. Historical Python executable
hash is documented, not claimed as a new observed result. No guarantees are made
about privileged interference, filesystem failure, simultaneous monitor stalls,
desktop/brokered escape, workload compatibility or hard descendant launch rate.

Production launch remains disabled. After upload, originating-chat source review
must precede its one separately controlled manual Windows run. This Cloud chat
must not dispatch, retry, release or install the candidate.
