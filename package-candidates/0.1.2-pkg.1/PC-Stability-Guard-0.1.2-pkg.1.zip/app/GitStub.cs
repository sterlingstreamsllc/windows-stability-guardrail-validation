// Synthetic git.exe image. Never invokes Git, opens a repository or uses the network.
using System;
using System.Threading;
internal static class GitStub {
    public static int Main(string[] args) {
        int ms = 400;
        if (args.Length > 0 && !Int32.TryParse(args[0], out ms)) return 2;
        Thread.Sleep(Math.Max(0, Math.Min(ms, 4000)));
        return 0;
    }
}

