# Immutable second hosted run: FAIL (0.1.1)

Owner-supplied metadata, recorded 2026-10-21. The originating chat downloaded and
verified the raw artifact. This Cloud chat has not downloaded or authenticated its
bytes. This document is source review history, not a replacement raw receipt.

- Source: 255f256ca6525ef190cf8069396f67ae448b57c8, branch
  codex/fix-stability-guardrail-0-1-1; original baseline remains
  c8e382ec3187f68da2a432cec58d61facd94c50b.
- Run: https://github.com/sterlingstreamsllc/windows-stability-guardrail/actions/runs/39656678885
- Job: 119418697149. Artifact: 12372162247.
- Raw ZIP: 18959 bytes, 18 entries; SHA256
  349e9d04c90230a94a57c13bdd982d99d13271f869305d5f99cb19457ce1dd2c.
- normal, fanout, failure, memory-denial and hang: PASS. failed-launch: FAIL.
  The remaining 15 of 21 cases were unexecuted. Suite 13.4460685 seconds,
  job 43 seconds, run 47 seconds. The assertion failure remains FAIL.
- Python 3.13.16 x64; executable SHA256
  31fe10b4ed82a2f960af0ef9931f46a4b84ff286f8b6ffd9dee098cf4f10f17f.
  Windows Server 2025 10.0.26100, windows-2025-vs2026 image 20261007.264.1.
  All source hashes matched the canonical 0.1.1 manifest.

tests.py:408 required CreateProcessW error 193. The first error was instead
`{"type":"NativeError","operation":"CreateProcessW","pid":null,"winerror":216}`.
guard.py:453 supplied the 19 ASCII bytes `not a PE executable` as
invalid-fixture.exe. Circuit OPEN, controller exit 20, final active=0, total=0,
CPU=0, peak commit=0, watchdog_exit_confirmed=true, cleanup_errors=[].
No arbitrary native error is acceptable in place of the intended assertion.

The earlier error-87 case now recorded exact exit 7 and passed in this run.
This does not establish the historical cause of error 87 or reclassify the first
run's FAIL. Likewise the 216 error name alone does not establish why the old
plain-text fixture selected that loader result. No exact pinned-version known
issue was confirmed by the originating chat's bounded search or the subsequent
Cloud check recorded in OFFICIAL-SOURCES-0.1.2.md.

0.1.2 changes the intentional fixture, preserves the exact 193 acceptance target,
and strengthens its attribution and no-start evidence. It does not reinterpret
this run or claim that its 15 unexecuted cases passed.
