"""PC Stability Guard 0.1.2. SYNTHETIC ONLY; no production launch path."""
import argparse
from collections import deque
import hashlib
import json
import logging
from logging.handlers import RotatingFileHandler
import os
from pathlib import Path
import sys
import time
import tempfile
import uuid
# Isolated Python omits the script directory; trust only this package directory.
sys.path.insert(0, str(Path(__file__).resolve().parent))
import native as N
import pe_fixture as PF

BASE = Path(__file__).resolve().parent
STATE = BASE / "state"
SCRATCH = BASE / "scratch"
CASES = ("normal", "fanout", "failure", "memory-denial", "hang",
         "failed-launch", "parent-exit", "breakaway", "pressure",
         "commit-pressure", "controller-hang", "watchdog-exit", "churn",
         "git-fanout", "git-rate")
GIB = 1024**3

def atomic(path, value):
    data = json.dumps(value, sort_keys=True, indent=2).encode("utf-8")
    if len(data) > 32768:
        raise RuntimeError("STATE_SIZE_LIMIT")
    fd, name = tempfile.mkstemp(prefix=path.name+".", suffix=".new", dir=path.parent)
    tmp = Path(name)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException as ex:
        ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + N.cleanup([("RemoveAtomicTemp", lambda:tmp.unlink(missing_ok=True))])
        raise
    else:
        tmp.unlink(missing_ok=True)

def state_lock():
    identity = hashlib.sha256(str(BASE).casefold().encode()).hexdigest()[:24]
    return N.Mutex("Local\\PCSG-state-"+identity, timeout=1000)

def current_runtime():
    return read(STATE/"runtime.json") if (STATE/"runtime.json").exists() else {}

def same_run(expected, actual):
    return (expected.get("run_id") == actual.get("run_id") and
            expected.get("epoch") == actual.get("epoch") and
            expected.get("job") == actual.get("job"))

def publish_runtime(runtime):
    with state_lock():
        actual = current_runtime()
        if not same_run(runtime, actual):
            raise RuntimeError("STALE_RUN_STATE_PUBLICATION")
        if (STATE/"breaker.json").exists() or (STATE/"watchdog-trip.json").exists():
            raise RuntimeError("EXTERNAL_CIRCUIT_TRIP")
        atomic(STATE/"runtime.json", runtime)


def read(path):
    if path.stat().st_size > 32768:
        raise RuntimeError("STATE_SIZE_LIMIT")
    return json.loads(path.read_text(encoding="utf-8"))

def policy():
    p = read(BASE / "config.json")
    expected = {"schema":1, "mode":"synthetic-only", "automatic_retries":0,
                "failure_trip_count":1, "max_active_processes":2}
    for k,v in expected.items():
        if p.get(k) != v:
            raise RuntimeError("UNQUALIFIED_POLICY_" + k)
    ci = p.get("baseline_profile") == "ci-synthetic"
    if ci and not (os.environ.get("GITHUB_ACTIONS") == "true" and
                   os.environ.get("RUNNER_ENVIRONMENT") == "github-hosted"):
        raise RuntimeError("CI_BASELINE_PROFILE_REQUIRES_HOSTED_RUNNER")
    bounds = {
        "max_job_memory_mib":(64,256), "max_process_memory_mib":(48,192),
        "cpu_percent":(1,20), "job_user_cpu_seconds":(1,8),
        "wall_seconds":(2,20), "poll_seconds":(1,2),
        "heartbeat_seconds":(3,5), "critical_samples":(2,4),
        "warn_available_gib":(8,32), "stop_available_gib":(6,32),
        "stop_commit_gib":(6,32), "max_starts_per_60_seconds":(2,10),
        "log_bytes":(65536,262144), "log_backups":(1,2)}
    for k,(lo,hi) in bounds.items():
        if ci and k in ("warn_available_gib","stop_available_gib","stop_commit_gib"):
            lo,hi = (1,32) if k == "warn_available_gib" else (.5,32)
            valid_type = type(p.get(k)) in (int,float)
        else:
            valid_type = type(p.get(k)) is int
        if not valid_type or not lo <= p[k] <= hi:
            raise RuntimeError("INVALID_POLICY_" + k)
    if p["max_process_memory_mib"] > p["max_job_memory_mib"]:
        raise RuntimeError("PROCESS_MEMORY_EXCEEDS_JOB_MEMORY")
    if p["warn_available_gib"] < p["stop_available_gib"]:
        raise RuntimeError("INVALID_HYSTERESIS")
    return p

def log(name, p):
    logger = logging.getLogger(name)
    logger.setLevel(logging.INFO)
    logger.propagate = False
    class StrictHandler(RotatingFileHandler):
        def handleError(self, record):
            raise RuntimeError("AUDIT_WRITE_FAILED")
    h = StrictHandler(STATE / (name+".jsonl"), maxBytes=p["log_bytes"],
                      backupCount=p["log_backups"], encoding="utf-8")
    h.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(h)
    return logger

def emit(logger, event, **fields):
    # Do not record argv, environment, output, credentials or repository content.
    logger.info(json.dumps(dict(utc=time.time(), event=event, **fields),
                           sort_keys=True))

def critical(p, m):
    if m["available"] < p["stop_available_gib"] * GIB:
        return "PHYSICAL_HEADROOM"
    if m["commit_headroom"] < p["stop_commit_gib"] * GIB:
        return "COMMIT_HEADROOM"
    return None

def breaker_reason():
    for f in ("breaker.json","watchdog-trip.json"):
        if (STATE/f).exists():
            return f
    if (STATE/"runtime.json").exists():
        r = read(STATE/"runtime.json")
        if r.get("state") != "CLOSED":
            return "UNCLEAN_PREVIOUS_RUN"
    return None

def trip_record(reason, expected):
    # Caller holds state_lock. Preserve the first trip for this generation.
    actual = current_runtime()
    if not same_run(expected, actual):
        raise RuntimeError("STALE_RUN_TRIP_REFUSED")
    if not (STATE/"breaker.json").exists():
        atomic(STATE/"breaker.json", {"state":"OPEN", "reason":reason,
               "run_id":expected.get("run_id"), "epoch":expected.get("epoch"),
               "utc":time.time()})

def require_empty(name, reason):
    if not name:
        return
    try:
        j = N.Job(name)
    except OSError as ex:
        if ex.winerror != 2:
            raise
    else:
        try:
            if j.accounting()["active"]:
                raise RuntimeError(reason)
        except BaseException as ex:
            ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + N.cleanup([("Job.close", j.close)])
            raise
        else:
            j.close()

def reset(owner):
    if not owner:
        raise RuntimeError("EXPLICIT_OWNER_RESET_REQUIRED")
    STATE.mkdir(exist_ok=True)
    with N.Mutex():
        with state_lock():
            r = current_runtime()
            require_empty(r.get("job"), "RESET_REFUSED_ACTIVE_WORKLOAD")
            require_empty(r.get("watchdog_job"), "RESET_REFUSED_ACTIVE_WATCHDOG")
            logger = log("operator", policy())
            emit(logger, "owner-reset", previous_reason=breaker_reason(), run_id=r.get("run_id"))
            # A new epoch invalidates any already-captured emergency/watchdog writer.
            pending = {**r, "state":"RESETTING", "epoch":uuid.uuid4().hex,
                       "reset_utc":time.time(), "verified_production":False}
            atomic(STATE/"runtime.json", pending)
            for f in ("breaker.json","watchdog-trip.json"):
                (STATE/f).unlink(missing_ok=True)
            atomic(STATE/"runtime.json", {**pending, "state":"CLOSED"})

def status():
    if not STATE.exists():
        print(json.dumps({"state":"NOT_STARTED", "production":"DISABLED",
                          "desktop_coverage":"UNPROTECTED"}))
        return
    r = read(STATE/"runtime.json") if (STATE/"runtime.json").exists() else {}
    r["breaker"] = breaker_reason() or "CLOSED"
    r["production"] = "DISABLED"
    r["desktop_coverage"] = "UNPROTECTED"
    if r.get("job"):
        try:
            j = N.Job(r["job"])
            try:
                r["live_job"] = j.accounting()
            except BaseException as ex:
                ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + N.cleanup([("StatusJob.close", j.close)])
                raise
            else:
                j.close()
        except OSError as ex:
            r["live_job_error"] = ex.winerror
    print(json.dumps(r, sort_keys=True))

def emergency():
    if not STATE.exists() or not (STATE/"runtime.json").exists():
        print("NO_IDENTIFIED_JOB; NO_PROCESS_TERMINATED")
        return
    r = current_runtime()
    if not r.get("job") or not r["job"].startswith("Local\\PCSG-work-"):
        raise RuntimeError("NO_VALID_SUPERVISED_JOB_IDENTITY")
    if "--ci-stop-barrier" in sys.argv:
        require_ci_hooks()
        (SCRATCH/"ci-stop-captured").write_text("captured", encoding="utf-8")
        deadline = time.monotonic()+8
        while not (SCRATCH/"ci-stop-release").exists():
            if time.monotonic()>deadline:
                raise RuntimeError("CI_STOP_BARRIER_TIMEOUT")
            time.sleep(.05)
    found = True
    try:
        j = N.Job(r["job"])
    except OSError as ex:
        if ex.winerror != 2:
            raise
        found = False
    else:
        try:
            # Never acquire controller/state locks before direct emergency kill.
            j.terminate()
            deadline = time.monotonic()+3
            while time.monotonic() < deadline and j.accounting()["active"]:
                time.sleep(.1)
            if j.accounting()["active"]:
                raise RuntimeError("TERMINATION_NOT_CONFIRMED")
        except BaseException as ex:
            ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + N.cleanup([("Job.close", j.close)])
            raise
        else:
            j.close()
    print("SUPERVISED_JOB_EMPTY; CIRCUIT_PUBLICATION_PENDING" if found else
          "NO_LIVE_JOB; CIRCUIT_PUBLICATION_PENDING", flush=True)
    with state_lock():
        trip_record("EMERGENCY_STOP" if found else "EMERGENCY_STOP_NO_LIVE_JOB", r)
        logger = log("operator", policy())
        emit(logger, "emergency-stop", run_id=r.get("run_id"), job_empty=found)
    print("SUPERVISED_JOB_EMPTY; CIRCUIT_OPEN" if found else "NO_LIVE_JOB; CIRCUIT_OPEN")

def watchdog(job_name, pulse_name, ack_name, done_name, test_case):
    j = pulse = ack = done = logger = None
    reason = None
    expected = None
    primary_error = None
    exit_status = 72
    try:
        p = policy()
        logger = log("watchdog", p)
        expected = current_runtime()
        if expected.get("job") != job_name:
            raise RuntimeError("WATCHDOG_RUN_IDENTITY_MISMATCH")
        j = N.Job(job_name)
        pulse = N.Event(pulse_name)
        ack = N.Event(ack_name)
        done = N.Event(done_name)
        last_pulse = start = time.monotonic()
        streak = 0
        previous_defender = {}
        last_defender = 0.0
        ack.set()
        while True:
            if done.wait(0):
                exit_status = 0
                break
            now = time.monotonic()
            if pulse.wait(0):
                last_pulse = now
                ack.set()
            if now-last_pulse > p["heartbeat_seconds"]:
                reason = "CONTROLLER_HEARTBEAT_LOST"
                break
            if now-start > p["wall_seconds"]+8:
                reason = "WATCHDOG_ABSOLUTE_DEADLINE"
                break
            m = N.system_memory()
            hit = critical(p,m)
            streak = streak+1 if hit else 0
            if streak >= p["critical_samples"]:
                reason = hit
                break
            if now-last_defender >= 5:
                # At most one Toolhelp snapshot per five seconds.
                last_defender = now
                readings = []
                try:
                    for pid,parent,name in N.process_snapshot():
                        if name.lower() != "msmpeng.exe":
                            continue
                        handle = None
                        try:
                            # VM/read rights may be denied for Defender's protected process.
                            handle = N.check(N.OpenProcess(0x1000 | 0x10, False, pid), "OpenProcess.Defender", pid)
                            v = N.memory_and_cpu(handle, pid)
                            old = previous_defender.get(pid)
                            cpu = None if old is None else max(
                                0, (v["cpu_seconds"]-old[1])/(now-old[0])*100)
                            previous_defender[pid] = (now,v["cpu_seconds"])
                            readings.append({"pid":pid, **v, "cpu_one_core_percent":cpu})
                        except OSError as ex:
                            readings.append({"pid":pid, "reading":"ACCESS_DENIED"
                                if getattr(ex,"winerror",None)==5 else "UNAVAILABLE",
                                "native_error":N.error_context(ex)})
                        finally:
                            if handle:
                                N.close(handle)
                    emit(logger, "defender-observation", readings=readings,
                         warning_calibration="UNAVAILABLE")
                except OSError as ex:
                    emit(logger, "defender-observation", reading="UNAVAILABLE", error=N.error_context(ex))
            if test_case == "watchdog-exit" and now-start > 2:
                exit_status = 71
                break
            time.sleep(p["poll_seconds"])
    except BaseException as ex:
        reason = "WATCHDOG_ERROR_" + type(ex).__name__
        primary_error = N.error_context(ex)
    finally:
        errors = []
        if reason:
            # Kernel termination precedes state/log locks and their possible failure.
            if j:
                errors.extend(N.cleanup([("TerminateJobObject", j.terminate)]))
            try:
                with state_lock():
                    if expected is None or not same_run(expected, current_runtime()):
                        raise RuntimeError("STALE_WATCHDOG_TRIP_REFUSED")
                    atomic(STATE/"watchdog-trip.json", {"state":"OPEN", "reason":reason,
                           "run_id":expected["run_id"], "epoch":expected["epoch"],
                           "utc":time.time(), "first_error":primary_error, "cleanup_errors":errors})
                    if logger:
                        emit(logger, "trip", reason=reason, error=primary_error, cleanup_errors=errors)
            except BaseException:
                pass  # OPEN_RUN persists; controller also detects watcher exit.
        errors.extend(N.cleanup([(type(obj).__name__+".close", obj.close)
                                 for obj in (done,ack,pulse,j) if obj]))
        if errors:
            exit_status = 72
            if logger:
                N.cleanup([("AuditWatchdogCleanup", lambda:emit(logger,"cleanup-error",errors=errors))])
            print(json.dumps({"watchdog_cleanup_errors":errors}))
    return exit_status

def observe_exits(tracked, logger):
    failures = []
    for pid, t in tracked.items():
        code = N.exit_code(t["h"], pid)
        if code is not None and t["exit"] is None:
            t["exit"] = code
            emit(logger, "process-exit", pid=pid, code=code, git=t["git"])
        if t["exit"] is not None and t["exit"] != 0:
            failures.append({"pid":pid, "code":t["exit"]})
    return failures

def observe_child(j, pid, tracked, logger, event):
    if pid in tracked:
        return
    h = None
    try:
        h = N.process_handle(pid)
        if not j.contains(h, pid):
            raise RuntimeError("CHILD_IDENTITY_LOST")
        name = Path(N.image_name(h, pid)).name.lower()
        tracked[pid] = {"h":h, "git":name=="git.exe", "exit":None}
        h = None  # ownership transferred only after every identity check succeeds
        emit(logger, event, pid=pid, executable=name, parent="NOT_CAPTURED")
    except BaseException as ex:
        ex.observation_context = {"pid":pid, "observation":event}
        if h:
            ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + N.cleanup([("CloseUnregisteredProcess", lambda:N.close(h))])
        raise

def run(case):
    p = policy()
    if case not in CASES:
        raise ValueError("UNKNOWN_SYNTHETIC_CASE")
    STATE.mkdir(exist_ok=True)
    SCRATCH.mkdir(exist_ok=True)
    mutex = N.Mutex()
    j = wj = wp = pulse = ack = done = cancel = pi = None
    tracked = {}
    logger = None
    reason = None
    runtime = None
    primary_error = None
    cleanup_errors = []
    finished = False
    started = time.monotonic()
    try:
        # Persist uncertainty before creating any process.
        rid = uuid.uuid4().hex
        stem = "Local\\PCSG-" + rid
        job_name = "Local\\PCSG-work-" + rid
        reservation = {"state":"OPEN_RUN", "run_id":rid, "case":case,
                   "controller_pid":os.getpid(), "job":job_name, "epoch":rid,
                   "watchdog_job":stem+"-watchdog-job",
                   "desktop_coverage":"UNPROTECTED", "production":False}
        with state_lock():
            if breaker_reason() or mutex.abandoned:
                raise RuntimeError("CIRCUIT_OPEN_OWNER_RESET_REQUIRED")
            runtime = reservation
            atomic(STATE/"runtime.json", runtime)
        logger = log("controller", p)
        emit(logger, "run-reserved", case=case, run_id=rid)
        # A second launch within 60 seconds is refused. This conservatively
        # avoids cross-run burst accumulation. It is NOT a kernel spawn-rate cap.
        ratefile = STATE/"admission.json"
        if ratefile.exists():
            previous = read(ratefile).get("utc", time.time())
            if time.time()-previous < 60:  # clock rollback fails closed too
                raise RuntimeError("ADMISSION_BACKOFF_60_SECONDS")
        atomic(ratefile, {"utc":time.time(), "run_id":rid})
        m = N.system_memory()
        if critical(p,m):
            raise RuntimeError("UNSAFE_BASELINE")
        if case == "memory-denial":
            p = dict(p, max_process_memory_mib=64, max_job_memory_mib=128)
        j = N.Job(job_name, p)
        pulse = N.Event(stem+"-pulse", True)
        ack = N.Event(stem+"-ack", True)
        done = N.Event(stem+"-done", True, manual=True)
        cancel = N.Event(stem+"-cancel", True, manual=True)
        wp_policy = dict(p, max_active_processes=1, max_job_memory_mib=128,
                         max_process_memory_mib=96, cpu_percent=5,
                         job_user_cpu_seconds=8)
        wj = N.Job(stem+"-watchdog-job", wp_policy)
        wp = N.launch(wj, [sys.executable, "-I", str(BASE/"guard.py"), "_watchdog",
             job_name, stem+"-pulse", stem+"-ack", stem+"-done", case], str(BASE))
        N.resume(wp)
        if not ack.wait(3000):
            raise RuntimeError("WATCHDOG_NOT_READY")
        pulse.set()
        env = dict(os.environ)
        env["PCSG_CANCEL_EVENT"] = stem+"-cancel"
        env["PCSG_FIXTURE_RESULT"] = str(SCRATCH/"fixture.json")
        # Use only the checked-in dummy fixture; no arbitrary workload manifest.
        argv = [sys.executable, "-I", str(BASE/"fixtures.py"), case]
        if case == "failed-launch":
            require_ci_hooks()
            # The harness supplies the bounded DLL compiled from GitStub.cs.
            # Inspect bytes only; never LoadLibrary or invoke its managed code.
            invalid = SCRATCH/"failed-launch.dll"
            if invalid.stat().st_size > PF.MAX_BYTES:
                raise RuntimeError("FAILED_LAUNCH_FIXTURE_SIZE")
            fixture = PF.inspect_dll(invalid.read_bytes())
            prepared = read(SCRATCH/"launch-fixture.json")
            if fixture != prepared["image"]:
                raise RuntimeError("FAILED_LAUNCH_FIXTURE_IDENTITY_CHANGED")
            runtime.update(failed_launch_fixture=prepared,
                           limits_read_back=True, limits=j.limits(), watchdog_limits=wj.limits(),
                           watchdog_pid=int(wp.Pid), root_created=False, root_resumed=False)
            publish_runtime(runtime)
            emit(logger, "failed-launch-attempt", fixture=fixture)
            argv = [str(invalid)]
        pi = N.launch(j, argv, str(SCRATCH), env)
        tracked[int(pi.Pid)] = {"h":pi.Process, "git":False, "exit":None}
        if case == "failed-launch":
            # Unexpected success is a failure; retain ownership and never resume it.
            runtime.update(root_created=True, root_pid=int(pi.Pid))
            raise RuntimeError("FAILED_LAUNCH_UNEXPECTED_CREATE_SUCCESS")
        runtime.update(root_pid=int(pi.Pid), watchdog_pid=int(wp.Pid),
                       limits_read_back=True, limits=j.limits(), watchdog_limits=wj.limits(),
                       heartbeat_utc=time.time())
        publish_runtime(runtime)
        N.resume(pi)
        emit(logger, "root-start", pid=int(pi.Pid), parent=os.getpid(),
             executable_sha256=hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
             active_limit=p["max_active_processes"], job_mib=p["max_job_memory_mib"],
             process_mib=p["max_process_memory_mib"])
        last_ack = last_sample = started = time.monotonic()
        streak = 0
        last_total = 0
        starts = deque()
        warning = False
        while True:
            now = time.monotonic()
            if case == "controller-hang" and now-started > 2:
                # Finite simulated controller stall. Independent watchdog must act.
                if p.get("baseline_profile")=="ci-synthetic":
                    (SCRATCH/"ci-controller-stalled").write_text("stalled",encoding="utf-8")
                time.sleep(p["heartbeat_seconds"]+2)
            if (STATE/"breaker.json").exists() or (STATE/"watchdog-trip.json").exists():
                raise RuntimeError("EXTERNAL_CIRCUIT_TRIP")
            if N.exit_code(wp.Process, int(wp.Pid)) is not None:
                raise RuntimeError("WATCHDOG_EXIT")
            if ack.wait(0):
                last_ack = now
            if now-last_ack > p["heartbeat_seconds"]:
                raise RuntimeError("WATCHDOG_HEARTBEAT_LOST")
            pulse.set()
            if now-started > p["wall_seconds"]:
                raise RuntimeError("WALL_TIMEOUT")
            # Inspect retained process handles before any stale queued PID.
            failures = observe_exits(tracked, logger)
            runtime["observed_failures"] = failures
            if failures:
                raise RuntimeError("PROCESS_FAILURE")
            # Bounded event drain: unknown identities are never skipped.
            for unused in range(16):
                event = j.event(0)
                if event is None:
                    break
                message,pid = event
                emit(logger, "job-notification", message=message, pid=pid)
                if message in (1,2,3,8,9,10):
                    # Retained exits take precedence over generic abnormal messages.
                    failures = observe_exits(tracked, logger)
                    runtime["observed_failures"] = failures
                    if failures:
                        raise RuntimeError("PROCESS_FAILURE")
                    raise RuntimeError("JOB_LIMIT_OR_ABNORMAL_EXIT_" + str(message))
                if message == 6:
                    observe_child(j, pid, tracked, logger, "child-observed")
            a = j.accounting()
            # Cumulative OS counter catches starts that event delivery missed.
            delta = a["total"]-last_total
            if delta < 0:
                raise RuntimeError("COUNTER_REGRESSION")
            for unused in range(min(delta, p["max_starts_per_60_seconds"]+1)):
                starts.append(now)
            last_total = a["total"]
            while starts and now-starts[0] > 60:
                starts.popleft()
            if a["total"] > p["max_starts_per_60_seconds"] or len(starts)>p["max_starts_per_60_seconds"]:
                raise RuntimeError("PROCESS_CREATION_RATE")
            # Reconcile active descendants even when the NEW_PROCESS notification is lost.
            for pid in j.pids():
                observe_child(j, pid, tracked, logger, "child-reconciled")
            a = j.accounting()  # attribution must compare against a fresh counter
            if a["total"] != len(tracked):
                raise RuntimeError("PROCESS_OBSERVABILITY_LOST")
            failures = observe_exits(tracked, logger)
            runtime["observed_failures"] = failures
            if failures:
                raise RuntimeError("PROCESS_FAILURE")
            if now-last_sample >= p["poll_seconds"]:
                last_sample = now
                m = N.system_memory()
                # Test-only injected readings; no real memory pressure generation.
                measured = dict(m)
                if case == "pressure":
                    measured["available"] = 0
                if case == "commit-pressure":
                    measured["commit_headroom"] = 0
                hit = critical(p,measured)
                streak = streak+1 if hit else 0
                if streak >= p["critical_samples"]:
                    raise RuntimeError("SIMULATED_"+hit if case in (
                        "pressure","commit-pressure") else hit)
                if measured["available"] < p["warn_available_gib"]*GIB and not warning:
                    warning = True
                    emit(logger, "memory-warning", **measured)
                elif measured["available"] > (p["warn_available_gib"]+1)*GIB:
                    warning = False
                git_active = sum(t["git"] and t["exit"] is None for t in tracked.values())
                e = j.extended()
                runtime.update(heartbeat_utc=time.time(), accounting=a,
                               git_observed_active=git_active, memory=m,
                               peak_job_commit=int(e.PeakJobMemory),
                               process_observation="COMPLETE_SO_FAR")
                publish_runtime(runtime)
                emit(logger, "sample", **a, **m, git_active=git_active,
                     peak_job_commit=int(e.PeakJobMemory))
            if tracked[int(pi.Pid)]["exit"] is not None:
                if a["active"]:
                    raise RuntimeError("ROOT_EXIT_WITH_DESCENDANTS")
                finished = True
                break
            time.sleep(.1)
    except BaseException as ex:
        reason = str(ex) if isinstance(ex, RuntimeError) else type(ex).__name__
        primary_error = N.error_context(ex)
        cleanup_errors.extend(getattr(ex, "cleanup_errors", []))
        if runtime is not None and (isinstance(ex, N.NativeError) or reason in (
                "PROCESS_OBSERVABILITY_LOST", "CHILD_IDENTITY_LOST")):
            runtime["observability_error"] = primary_error
        # No exception text from arbitrary OS paths or commands enters diagnostics.
        if logger:
            try:
                emit(logger, "trip", reason=reason, error=primary_error)
            except Exception:
                pass
    finally:
        # Each step is attempted; first execution error never replaced by cleanup.
        def attempt(operation, action):
            cleanup_errors.extend(N.cleanup([(operation, action)]))
        if j:
            if not finished:
                attempt("TerminateWorkJob", j.terminate)
            def readback():
                deadline = time.monotonic()+3
                while j.accounting()["active"] and time.monotonic()<deadline:
                    time.sleep(.1)
                a = j.accounting()
                if a["active"]:
                    raise RuntimeError("JOB_EMPTY_NOT_CONFIRMED")
                runtime["final_accounting"] = a
                runtime["final_peak_job_commit"] = int(j.extended().PeakJobMemory)
                # Even a known root failure does not certify unknown children.
                runtime["process_observation"] = ("COMPLETE" if a["total"] == len(tracked)
                                                  else "INCOMPLETE")
                if a["total"] != len(tracked):
                    raise RuntimeError("PROCESS_OBSERVABILITY_LOST")
            attempt("WorkJobReadback", readback)
        if done:
            attempt("SignalWatchdogDone", done.set)
        if wj:
            attempt("TerminateWatchdogJob", wj.terminate)
        watchdog_stopped = wp is None
        if wp:
            before = len(cleanup_errors)
            attempt("WaitWatchdogExit", lambda:N.wait_exit(wp.Process, 3000, int(wp.Pid)))
            watchdog_stopped = len(cleanup_errors) == before
        elif wj:
            # N.launch may have created a process and then failed before returning.
            # Its exception cleanup waits on the owned handle; also verify job empty.
            before = len(cleanup_errors)
            def empty_watcher():
                deadline = time.monotonic()+3
                while wj.accounting()["active"] and time.monotonic()<deadline:
                    time.sleep(.1)
                if wj.accounting()["active"]:
                    raise RuntimeError("WATCHDOG_TERMINATION_NOT_CONFIRMED")
            attempt("ConfirmPartialWatchdogLaunchEmpty", empty_watcher)
            watchdog_stopped = len(cleanup_errors) == before
        # No final CLOSED publication or reset until the watcher is proven dead.
        if runtime is not None:
            runtime["watchdog_exit_confirmed"] = watchdog_stopped
        if wp:
            attempt("CloseWatchdogThread", lambda:N.close(wp.Thread))
            attempt("CloseWatchdogProcess", lambda:N.close(wp.Process))
        if wj:
            attempt("CloseWatchdogJob", wj.close)
        for t in tracked.values():
            attempt("CloseTrackedProcess", lambda t=t:N.close(t["h"]))
        if pi and pi.Thread:
            attempt("CloseRootThread", lambda:N.close(pi.Thread))
        for obj in (cancel,done,ack,pulse,j):
            if obj:
                attempt("Close"+type(obj).__name__, obj.close)
        if cleanup_errors:
            finished = False
            reason = reason or "CLEANUP_FAILED"
        try:
            if runtime is not None:
                with state_lock():
                    if not same_run(runtime, current_runtime()):
                        raise RuntimeError("STALE_FINAL_STATE_REFUSED")
                    if breaker_reason() in ("breaker.json", "watchdog-trip.json"):
                        finished = False
                        reason = reason or "EXTERNAL_CIRCUIT_TRIP"
                    runtime.update(state="CLOSED" if finished else "OPEN", reason=reason,
                                   first_error=primary_error, cleanup_errors=cleanup_errors,
                                   elapsed_seconds=time.monotonic()-started)
                    if not finished:
                        trip_record(reason or "UNKNOWN_FAILURE", runtime)
                    atomic(STATE/"runtime.json", runtime)
        except BaseException as ex:
            finished = False
            reason = reason or "FINAL_STATE_PUBLICATION_FAILED"
            cleanup_errors.append(N.error_context(ex, "FinalPublication"))
        finally:
            before = len(cleanup_errors)
            attempt("ReleaseAdmissionMutex", mutex.close)
            if len(cleanup_errors) != before:
                finished = False
                reason = reason or "MUTEX_CLEANUP_FAILED"
    print(json.dumps({"case":case, "state":"CLOSED" if finished else "OPEN",
                      "reason":reason, "first_error":primary_error,
                      "cleanup_errors":cleanup_errors, "production":"DISABLED"}))
    return 0 if finished else 20

def require_ci_hooks():
    if not (policy().get("baseline_profile")=="ci-synthetic" and
            os.environ.get("GITHUB_ACTIONS")=="true" and
            os.environ.get("RUNNER_ENVIRONMENT")=="github-hosted"):
        raise RuntimeError("CI_HOOK_REQUIRES_DISPOSABLE_HOSTED_PROFILE")

def main():
    args = sys.argv[1:]
    if args==["_ci_hold_state"]:
        require_ci_hooks()
        with state_lock():
            (SCRATCH/"ci-state-lock-held").write_text("held",encoding="utf-8")
            time.sleep(2.5)
        return 0
    if args[:1] == ["_watchdog"]:
        if len(args) != 6 or not args[1].startswith("Local\\PCSG-work-") or args[-1] not in CASES:
            raise RuntimeError("INVALID_WATCHDOG_ARGUMENTS")
        return watchdog(*args[1:])
    parser = argparse.ArgumentParser(description="Source candidate; synthetic-only launcher")
    parser.add_argument("command", choices=("status","stop","reset","run","launch"))
    parser.add_argument("case", nargs="?")
    parser.add_argument("--owner-reset", action="store_true")
    parser.add_argument("--ci-stop-barrier", action="store_true", help=argparse.SUPPRESS)
    a = parser.parse_args()
    if a.command == "status":
        status()
    elif a.command == "stop":
        emergency()
    elif a.command == "reset":
        reset(a.owner_reset)
    elif a.command == "launch":
        raise RuntimeError("LIVE_WORKLOADS_DISABLED_PENDING_INDEPENDENT_VALIDATION_AND_OWNER_APPROVAL")
    else:
        return run(a.case)
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except BaseException as exc:
        if isinstance(exc, SystemExit):
            raise
        print(json.dumps({"state":"REFUSED", "error":str(exc)
                         if isinstance(exc, RuntimeError) else type(exc).__name__,
                         "first_error":N.error_context(exc),
                         "cleanup_errors":getattr(exc,"cleanup_errors",[])}))
        sys.exit(30)

