@echo off
echo PC Stability Guard 0.1.2-pkg.1 preparation candidate.
echo Production launch is disabled. No installation or workload starts here.
echo Read LOCAL-VALIDATION-PLAN.md, OPERATOR-CARD.txt and VERIFICATION-REPORT.md.
echo Do not use the historical app command wrappers.
