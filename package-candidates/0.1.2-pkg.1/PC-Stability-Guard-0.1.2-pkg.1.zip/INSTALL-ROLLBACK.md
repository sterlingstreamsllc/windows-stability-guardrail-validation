# File-copy staging and evidence-preserving rollback

Candidate 0.1.2-pkg.1, Windows behavior UNEXECUTED. Current authority is remote
preparation only. All commands below are for a future explicitly approved owner
session in ordinary standalone terminals, after reviewing the local plan.

Use the independently delivered SHA256SUMS and APPROVAL-TEMPLATE.txt. Verify the
external Package.ps1 digest using built-in Get-FileHash before running it. Do not
derive trust solely from a hash shipped in the same untrusted ZIP. The archive
hash anchors PACKAGE-MANIFEST.json; its external hash anchors installed checks.
These hashes provide integrity relative to the reviewed artifact, not a code
signing certificate or automatic Windows trust approval.

Substitute the actual absolute paths and the three exact external digests below.
Never paste placeholders. `$R` is the approved per-user destination, not an
arbitrary override; the script verifies it against LocalApplicationData.

```powershell
Get-FileHash -LiteralPath 'C:\Users\OWNER\Downloads\Package.ps1' -Algorithm SHA256
Get-FileHash -LiteralPath 'C:\Users\OWNER\Downloads\PC-Stability-Guard-0.1.2-pkg.1.zip' -Algorithm SHA256
$R = 'C:\Users\OWNER\AppData\Local\PC-Stability-Guard-0.1.2-pkg.1'
$Z = 'C:\Users\OWNER\Downloads\PC-Stability-Guard-0.1.2-pkg.1.zip'
$H = 'ACTUAL_REVIEWED_ZIP_SHA256'
$M = 'ACTUAL_REVIEWED_PACKAGE_MANIFEST_SHA256'
& 'C:\Users\OWNER\Downloads\Package.ps1' -Action InspectArchive -ZipPath $Z -ArchiveSHA256 $H
& 'C:\Users\OWNER\Downloads\Package.ps1' -Action Stage -ZipPath $Z -ArchiveSHA256 $H -Root $R -OwnerApproved
& "$R\Package.ps1" -Action InspectInstalled -Root $R -ManifestSHA256 $M
```

Stage validates every ZIP name, entry size/type, case collision and file hash,
then writes using CreateNew into a fresh fixed directory. It rejects reparse
ancestors and never overwrites. Partial staging failure is preserved in place;
do not delete it or rerun into it. Repeated path checks protect against existing
unsafe paths, not a hostile same-user process racing filesystem changes. Keep
the owner session quiescent; no hostile concurrent mutator is within this
prototype's boundary. This is file-copy staging, not an OS installation.

After a **separate** approved one-normal trial, these are the package commands:

```powershell
& "$R\Package.ps1" -Action Baseline -Root $R -ManifestSHA256 $M -OwnerApproved
& "$R\Package.ps1" -Action Status -Root $R -ManifestSHA256 $M -OwnerApproved
& "$R\Package.ps1" -Action Normal -Root $R -ManifestSHA256 $M -OwnerApproved
```

Run each once and inspect its result before the next. Baseline/status create
unique receipts, not workloads. Normal refuses a preexisting attempt marker or
runtime.json. No reset command is exposed. Never use app/guard.cmd or the other
historical app/*.cmd launchers: their old environment/PATH behavior is preserved
as tested source history, not supported package entrypoints. Package.ps1 uses
only this root's absolute runtime/python.exe; PCSG_PYTHON and PATH overrides are
ignored. START-HERE.cmd prints information only, including on double-click.

Emergency stop is the direct CMD command in OPERATOR-CARD.txt. Package.ps1 Stop
also exists, but is not the independent emergency path: it validates critical
code, then stops before snapshots or mutable-state integrity checks. Stop does
not promise recovery from missing/corrupt trusted code. The direct CMD path is
prepared against already verified code and does not traverse receipts.

For approved rollback after all work is stopped:

```powershell
& "$R\Package.ps1" -Action Quarantine -Root $R -ManifestSHA256 $M -OwnerApproved -OwnerConfirmedStopped
```

Quarantine requires valid immutable hashes, final zero active processes and
confirmed watchdog exit when runtime.json exists, and refuses if any recorded
controller/root/watchdog PID is currently present (even if reused). It then
renames the whole tree to a unique `.quarantine-UTC-GUID` sibling. It never
deletes, kills a process or clears evidence. Renaming is not a live-job test; the
owner must first confirm no commands are running. A partially staged/integrity-
damaged tree cannot use this action. A distinct recovery action is available
from the independently hash-verified external Package.ps1, only after the owner
explicitly confirms no commands/processes from this exact directory are running:

```powershell
& 'C:\Users\OWNER\Downloads\Package.ps1' -Action PreservePartial -Root $R -OwnerApproved -OwnerConfirmedStopped
```

PreservePartial validates only the fixed ordinary installation root and its
ancestors, then renames that whole directory to a unique sibling. It does not
execute/read the payload, require a healthy manifest, follow nested links,
traverse mutable files, or delete anything. It preserves partial staging, corrupt
files and nested link entries as evidence; it does not certify their integrity or
independently establish stopped state. If stopped state is unknown, leave the
directory untouched for review. This action is not a reset/retry. The renamed
tree is retained evidence; do not invoke its entrypoints or move it back without
separate review/authorization. Static hash comparison against its manifest is
still possible as inert data.

No registry, services, tasks, PATH/profile, security policy or global Python/Git
state is changed by the supplied scripts. No package script needs internet,
administrator rights, pip or a redistributable installer. Existing system
ucrtbase.dll is required. No runtime file or vendor ._pth is modified.

If PowerShell policy/MOTW or application control blocks any step, stop and retain
the exact error and step. No Unblock-File, ExecutionPolicy Bypass, policy changes,
encoded/inline re-execution of the blocked script, or transfer selected to strip
markings. Native Windows staging/rollback behavior remains unexecuted.
