@echo off
echo Reset closes the circuit only. It never restarts a workload.
call "%~dp0guard.cmd" reset --owner-reset
exit /b %errorlevel%
