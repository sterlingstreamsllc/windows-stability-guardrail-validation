# PC Stability Guard — source candidate 0.1.2

**Interim engineering prototype. SOURCE ONLY. NOT OPERATIONAL.**
The revised 0.1.2 source has static checks only; its Windows behavior is UNVERIFIED.
The historical 0.1.0 hosted run FAILED at failure after normal/fanout passed;
15 original cases were unexecuted. The 0.1.1 run FAILED at failed-launch after five
passes, leaving 15 cases unexecuted. Both failures are preserved in review-history.
Production launches remain deliberately refused.
The current deliverable is a reviewable implementation candidate and validation plan,
not a self-contained installer or an accepted safety system.

## Package

- guard.py: controller, persistent circuit breaker, synthetic launcher, independent
  watchdog mode, status and emergency stop.
- native.py: Windows x64 Job Object, process, memory and completion-port APIs.
- config.json: conservative workstation candidate policy.
- fixtures.py / GitStub.cs: finite dummy processes; the stub has no Git functionality.
- pe_fixture.py: bounded byte inspection of the AMD64 DLL used for failed-launch.
- tests.py: static checks and one hosted-Windows suite with 18 original cases plus 3 bounded concurrency cases.
- .github/workflows/windows-synthetic.yml: manual-only, ten-minute GitHub job.
- *.cmd: ordinary-window operator entry points.
- ARCHITECTURE.md, OPERATOR.md, VALIDATION.md, CLOUD-HANDOFF.md: boundaries and next steps.

No pip packages are required. Python 64-bit and Windows 10/11 are runtime
prerequisites. A future approved release must bundle a pinned, verified runtime and
carry independent Windows evidence. This package does not download or install one.

## Present gate status

| Gate | Status |
|---|---|
| A — source review, syntax/configuration | Static review only; see separate preparation receipt |
| B — isolated process/failure/memory tests | 0.1.2 NOT RUN; historical runs FAIL |
| C — descendant, interruption and escape tests | 0.1.2 NOT RUN |
| D — actual Codex containment/pilot | NOT AUTHORIZED; existing desktop UNPROTECTED |
| E — research restoration | NOT AUTHORIZED |

Do not deploy this candidate on a recovering workstation. Follow CLOUD-HANDOFF.md.
The runtime command "launch" refuses production work regardless of a config edit.

## First remote checks

In the isolated cloud repository, use:

    python -I tests.py --static-only

After separate owner approval, dispatch the included Windows workflow once with
approval input SYNTHETIC-ONLY. It stops on the first failed assertion, retains the
failure, and never automatically restarts the workload. Inspect all case receipts;
a green workflow is insufficient if the summary omits planned cases.

All claims are limited to the exact source, interpreter and runner image recorded
in the receipts. The hosted Python patch is pinned to the original run's 3.13.16 x64.
windows-latest still resolves its OS image at run time; receipts record that image,
OS, exact Python version and executable hash. No runtime update is part of this revision.

## 0.1.2 review and custody

Read REMEDIATION-0.1.2.md and review-history before considering the one additional
owner-approved diagnostic run. This cloud chat must never dispatch or retry it;
the originating chat reviews the uploaded branch and alone controls dispatch.
No owner-PC installation, desktop launch or research workload is authorized.

.gitattributes fixes LF provenance. The static gate verifies SOURCE-MANIFEST.json
before native import; the hosted gate verifies it again. The manifest excludes
itself to avoid self-hashing and excludes generated evidence and upload bundles.
Historical manifest bytes are preserved as an explicitly binary Git attribute.
Original hashes and LF-to-CRLF reconstruction remain in review-history.

The full static command is still `python -I tests.py --static-only` under Python
3.13. Cloud static validation does not import native.py or launch fixtures.
It inspects in-memory PE header specimens with the byte-only parser. The actual
DLL is compiled only on the separately controlled Windows runner from GitStub.cs,
using the existing compiler with /target:library /platform:x64. Its structure and
source/compiler/output hashes must agree before CreateProcessW is attempted.
Exactly error 193 is still required; no error-216 allowance or retry was added.
