@echo off
setlocal
if not defined PCSG_PYTHON exit /b 30
"%PCSG_PYTHON%" -I "%~dp0tests.py" --static-only
exit /b %errorlevel%
