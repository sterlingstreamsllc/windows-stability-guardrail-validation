# Remote development and independent validation handoff

Status: two historical hosted Windows FAIL runs are preserved in
review-history/FIRST-RUN.md and SECOND-RUN.md. 0.1.1 source is preserved at
255f256ca6525ef190cf8069396f67ae448b57c8. 0.1.2 repairs the failed-launch fixture
with exact error 193 still required; its Windows behavior remains NOT RUN.
See REMEDIATION-0.1.2.md and the original, unchanged REMEDIATION-0.1.1.md.

Owner update authorizes upload to codex/fix-failed-launch-0-1-2 and one
additional manual GitHub-hosted Windows diagnostic run, <=10 minutes, only after
originating-chat review. This cloud chat must not dispatch/retry that workflow.
The older proposal/prompt below is historical context; the current owner's
explicit constraints take precedence. No local installation or research use.

## Proposed external action requiring owner approval

Create a separate PRIVATE repository named windows-stability-guardrail in the
owner's selected GitHub account. Upload only the source ZIP's explicit manifest.
Do not upload local review notes, incident attachments, backups, production
receipts, credentials or research data.

Enable only the supplied manual workflow, then, only through the originating chat after source review, dispatch ONE windows-latest
synthetic run, maximum ten minutes, stopping on first failure. No schedule,
push/PR trigger, self-hosted runner, deployment permission or secret is needed.
Private Actions minutes may consume the account's included or paid allowance.
Read-only connector access does not establish repository-creation rights or quota.

Source and workflow are reviewable before approval. The initial run must follow
cloud source review. Changes after a failure preserve that run and get bounded
known-issue diagnosis; no automatic retest is included in this approval proposal.

## Start the cloud task

Use ChatGPT/Codex on the web to avoid keeping the recovering desktop app running.
Choose Work in > Cloud, then Select environment > Create environment. Select only
the new guardrail repository. Request a Python 3.13 environment for static work,
no research repositories, no host-drive mounts and no secrets. Review the setup,
publish the environment and start a task with the prompt below.

This is a new isolated cloud task, not a claim that this local session moved to
the cloud. Confirm the cloud environment/task identity before running commands.
If Cloud is unavailable, retain the static package; never substitute local tests.

Official instructions:
[Cloud environments](https://learn.chatgpt.com/docs/environments/cloud-environments)
and [Cloud overview](https://learn.chatgpt.com/docs/cloud), retrieved 2026-10-21.

## Prompt to paste in the cloud task

Develop this source-only Windows stability guardrail toward independently validated
interim capability. Read AGENTS.md, README.md, ARCHITECTURE.md, VALIDATION.md and
OPERATOR.md. Preserve the source baseline and any literal failures. The local
preparation ran only static Python parsing/configuration checks; no Windows
enforcement is demonstrated. Do not treat this package as an operational release.

First inspect source and run python -I tests.py --static-only. Review Windows ABI,
job assignment, handle lifetime, crash cleanup, watchdog independence, circuit/reset
races, emergency-stop scope and bounded logging. Fix blockers within this isolated
repository. Before remediation search the exact error and pinned version in
official issues/release notes/docs; retain sources and applicability. No research
repositories, data, models or production evidence may be accessed.

Windows behavior must be tested only through the owner-approved, manual,
GitHub-hosted windows-latest workflow. Ask for approval if the record does not
already authorize its creation/dispatch. Never use a self-hosted runner or the
recovering workstation. No real Git workload is part of the synthetic suite.
Stop after the first failed assertion, preserve receipts, and diagnose before
requesting any new executable run. No automatic retries or circuit resets outside
disposable test state.

A job's total process cap is hard; arbitrary-descendant rate detection is reactive.
Resolve or explicitly bound that distinction. Existing Codex desktop and brokered
processes are unprotected. Do not claim desktop coverage without Gate C proof.
No live Codex pilot, research restoration or local installation is authorized.

Deliver an independently reviewed test report tied to source/config/runtime hashes,
a bounded self-contained Windows package only after tests pass, and a rollback
card. Keep production launch disabled until owner acceptance and separately
authorized local validation. Do not modify scientific governance or rescore history.

## CI recipe and evidence custody

The supplied workflow pins action code by full commit SHA, uses a disposable
windows-latest runner, checks out only this small repository with credentials not
persisted, and uploads only generated ci-evidence for seven days.
Source/runtime/runner/commit identity is recorded. Preserve downloaded receipts
before retention expires. Hosted OS and Python patch versions must be pinned from
the successful run before a workstation release is qualified.

[GitHub-hosted runners](https://docs.github.com/en/actions/reference/runners/github-hosted-runners)
documents the runner model. The chosen action releases were retrieved 2026-10-21:
checkout v7.0.1, setup-python v7.0.0 and upload-artifact v7.0.2.
