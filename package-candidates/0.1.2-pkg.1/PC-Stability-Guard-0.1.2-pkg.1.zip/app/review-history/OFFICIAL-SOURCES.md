# Applicable official guidance reviewed before remediation

Retrieved 2026-10-21 through Microsoft's official documentation source on GitHub.
Rendered learn.microsoft.com/docs.python.org requests returned HTTP 403 in this
environment; no proxy bypass or TLS-verification change was used.

- https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_associate_completion_port
  Source: https://raw.githubusercontent.com/MicrosoftDocs/sdk-api/docs/sdk-api-src/content/winnt/ns-winnt-jobobject_associate_completion_port.md
  Explicitly warns that queued PIDs may have exited or been recycled without a
  retained open process handle. Applies to NEW_PROCESS observation; does not
  authorize ignoring unknown identity or converting error 87 to success.
- https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-openprocess
  Source: https://raw.githubusercontent.com/MicrosoftDocs/sdk-api/docs/sdk-api-src/content/processthreadsapi/nf-processthreadsapi-openprocess.md
  Requires handle closure; ERROR_INVALID_PARAMETER is documented for PID zero.
  Does not identify the unrecorded API/PID in the first-run failure.
- https://learn.microsoft.com/en-us/windows/win32/api/jobapi2/nf-jobapi2-terminatejobobject
  Source: https://raw.githubusercontent.com/MicrosoftDocs/sdk-api/docs/sdk-api-src/content/jobapi2/nf-jobapi2-terminatejobobject.md
  Termination acts as TerminateProcess on job members.
- https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-terminateprocess
  Source: https://raw.githubusercontent.com/MicrosoftDocs/sdk-api/docs/sdk-api-src/content/processthreadsapi/nf-processthreadsapi-terminateprocess.md
  External termination is asynchronous; wait on process handle to confirm exit.
- https://learn.microsoft.com/en-us/windows/win32/procthread/process-creation-flags
  Source: https://raw.githubusercontent.com/MicrosoftDocs/win32/docs/desktop-src/ProcThread/process-creation-flags.md
  DETACHED_PROCESS (0x8) avoids inherited console; CREATE_NO_WINDOW has separate
  semantics and is ignored when combined with DETACHED_PROCESS. The candidate
  uses DETACHED_PROCESS alone for finite synthetic native/fixture launches.
  No guarantee of absence of all system-created processes is inferred.
- https://learn.microsoft.com/en-us/windows/console/creation-of-a-console
  Source: https://raw.githubusercontent.com/MicrosoftDocs/Console-Docs/main/docs/creation-of-a-console.md
  Documents console inheritance/creation and detached-process behavior.
- https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_basic_limit_information
  Source: https://raw.githubusercontent.com/MicrosoftDocs/sdk-api/docs/sdk-api-src/content/winnt/ns-winnt-jobobject_basic_limit_information.md
  Reviewed during the second pass: association exceeding ActiveProcessLimit fails
  and terminates the attempted process. Fanout acceptance now requires a real
  process-limit notification, or quota-denial 1816 with one started child and
  exactly two attributed total starts; arbitrary launch errors are insufficient.

The owner's short known-issue searches found no confirmed product bug/fix for
Python 3.13.16 x64 / Windows Server 2025 build 26100 / error 87 in this signature.
This remediation follows API contracts, not a claimed runtime bug workaround.
No Python, Windows, action, compiler or runtime upgrade is made. Cloud static
interpreter remains 3.13.5; hosted setup requests exact 3.13.16 from the first run.
