# Operator card — do not install this source candidate

These are intended commands for a future independently validated package, in an
ordinary CMD window. They have NOT been executed during preparation.
No Administrator window is needed for the proposed user-mode controller.

## Prerequisites and release admission

1. Independent Windows receipts must show all required cases passed on pinned source,
   runtime and OS, including failure paths and measured overhead.
2. Owner explicitly approves local placement and a narrow synthetic acceptance run.
3. The owner closes Codex/ChatGPT desktop and its tray/background instance before
   local work. This package cannot protect that independently running application.
4. Verify the intended C:\PC-Stability-Guard location is still absent and has no
   inherited .git marker or reparse redirection. Do not initialize a repository.
5. A release engineer supplies a pinned, verified portable x64 Python runtime with
   license/checksums in the final package. The present source ZIP has no interpreter.
6. Baseline must meet physical/commit thresholds. Do not lower them to force a run.

## Intended commands

After the future package and interpreter have been separately approved and installed:

    cd /d C:\PC-Stability-Guard
    set "PCSG_PYTHON=C:\PC-Stability-Guard\runtime\python.exe"
    status.cmd

Expected initial JSON: state NOT_STARTED, production DISABLED,
desktop_coverage UNPROTECTED. A running job must report live_job.active, a recent
heartbeat_utc and limits_read_back true. A status file alone is not protection proof.

A separately approved local synthetic smoke run would be:

    guard.cmd run normal

Expected after qualification: exit code 0, state CLOSED, production DISABLED.
Do not run this now. There is no persistent background installation or start service:
a run starts its controller and watchdog; both finish when that workload finishes.

## Emergency stop

Keep an independent ordinary CMD window ready:

    emergency-stop.cmd

Expected success: SUPERVISED_JOB_EMPTY; CIRCUIT_OPEN.
If it reports NO_IDENTIFIED_JOB or NO_LIVE_JOB, that is not evidence the desktop
or any other process was stopped. No unrelated applications are terminated.

The current synthetic mode uses immediate job termination, because fixture data is
expendable. The cancellation event is reserved for a future cooperative checkpoint
adapter; this source candidate does not implement a graceful research shutdown.
If Windows itself cannot schedule the command, this tool cannot guarantee rescue.

## After a trip

Preserve the bounded state/log files and inspect the exact reason. Do not replay
failed research or reset historical outcomes. Once the owner explicitly decides it
is safe to reopen admission:

    owner-reset.cmd

Expected: exit 0. Then status.cmd reports breaker CLOSED. Reset never launches work
and does not clear the 60-second admission backoff. A reset while work remains active
must be refused. Never have an agent automatically reset the production circuit.

## Rollback

There is no registry, service, scheduled task, startup, Git, PATH or antivirus change
to undo. First stop the identified job and confirm zero active members. Preserve
state/logs and manifests. Close the dedicated CMD windows to discard their local
PCSG_PYTHON setting. Retain or rename the exact isolated installation folder after
checking its resolved path and absence of active jobs. No recursive deletion is
required. Return to the prior workflow only under the owner's separate decision;
removing this package does not make the prior unstable workflow safe.

The current source preparation requires no rollback of system settings: none were
changed and C:\PC-Stability-Guard was not created.

## 0.1.1 candidate clarification

No installation is authorized. Stop first targets the captured job without waiting
for controller or publication locks. SUPERVISED_JOB_EMPTY followed by
CIRCUIT_PUBLICATION_PENDING is only a termination observation; nonzero exit or
publication error must be preserved. Only the final CIRCUIT_OPEN message confirms
that this command persisted the trip. Never reset automatically after such errors.
Reset/new admission invalidates an already-captured stale stop through a run epoch;
a stale operation must be refused rather than alter the new generation.
