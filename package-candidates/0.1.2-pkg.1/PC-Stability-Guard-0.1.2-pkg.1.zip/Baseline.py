"""Approved local resource probe only. No workload, scan, changes or network."""
import json
from pathlib import Path
import sys
import time
import struct

if sys.version_info[:3] != (3,13,16) or not sys.flags.isolated or struct.calcsize('P') != 8:
    raise SystemExit("PINNED_ISOLATED_RUNTIME_REQUIRED")
sys.path.insert(0,str(Path(__file__).resolve().parent/"app"))
import native as N

m = N.system_memory()
print(json.dumps({"utc":time.time(),"python":sys.version,"executable":sys.executable,
    "isolated":bool(sys.flags.isolated),"pointer_bits":struct.calcsize('P')*8,
    "available_bytes":m["available"],"commit_headroom_bytes":m["commit_headroom"],
    "initial_physical_floor_bytes":8*1024**3,"initial_commit_floor_bytes":6*1024**3,
    "runtime_workloads":"NOT_STARTED"}))
