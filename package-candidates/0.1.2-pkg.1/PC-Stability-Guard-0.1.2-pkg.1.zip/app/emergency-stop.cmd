@echo off
call "%~dp0guard.cmd" stop
exit /b %errorlevel%
