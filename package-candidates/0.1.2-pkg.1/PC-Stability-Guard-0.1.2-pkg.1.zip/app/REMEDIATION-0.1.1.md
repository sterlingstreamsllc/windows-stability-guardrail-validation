# 0.1.1 source-only remediation report

Baseline: c8e382ec3187f68da2a432cec58d61facd94c50b.
Target branch: codex/fix-stability-guardrail-0-1-1. Main and baseline are preserved.
Hosted Cloud environment confirmed before shell work: provider=cloud, running,
observations_current=true; environment
ccarenv_b64_Y2NhcmVudl81YmYwYzEyYjA0YjA4MTkxOWQxOGNlZGUwY2VhNDgwYw.
No subagents, Windows execution, desktop launch, local installation, research
workload, credential extraction, workflow dispatch or retry occurred here.

## Preserved evidence and scope

review-history/cloud-review-0.1.0.md preserves the original review. The original
manifest is preserved byte-for-byte in review-history/SOURCE-MANIFEST-0.1.0.json.
FIRST-RUN.md records the owner's historical FAIL, two passed cases and 15 unexecuted
cases, artifact identity and exact Python/OS/runner versions. That historical FAIL
is not reclassified. Artifact bytes were not downloaded/authenticated by this chat.
EOL-PROVENANCE-0.1.0.json derives LF/CRLF byte counts and hashes from all five
baseline source/config blobs; the owner reports the CRLF hashes match first-run
receipts. The new .gitattributes pins LF and the manifest gate checks current bytes.

## Diagnosis and dispositions

Error 87: no pinned-version product bug or exact failing API/PID is established.
Official API guidance was reviewed before remediation (OFFICIAL-SOURCES.md).
Retained process exits now precede queued PID notifications, so an already-known
root exit can be recorded without a stale notification masking it. Errors carry
operation/PID/winerror and observation context. Unknown identities and incomplete
cumulative process attribution still fail closed. Explicit DETACHED_PROCESS is
used instead of CREATE_NO_WINDOW for finite synthetic creation, including fixture
children. No in-job system helper is exempt from the cap/accounting. This addresses
the diagnosed design weaknesses, but resolution of the observed error requires the
single separately controlled Windows run; no successful native result is claimed.

1. Watchdog lifetime: controller requests termination and waits on its retained
   process handle before final publication; reset independently checks both jobs
   empty. Failure to confirm exit cannot yield CLOSED. Runtime receipts expose the
   confirmation and secondary cleanup errors. Windows behavior remains unverified.
2. Circuit/state races: short per-package named publication mutex, unique fsynced
   atomic temporary files, run/job/epoch checks, and RESETTING-before-clear prevent
   stale publication or interrupted-reset reopening. Emergency job termination and
   empty-member readback occur before state-lock acquisition, with an explicit
   pending-publication message and nonzero refusal on lock failure. Controller
   admission/reset retain the session singleton. New bounded concurrency cases
   exercise contenders, a stalled controller, locked publication and stale stop.
3. Handle ownership/first errors: immediate process-handle registration, guarded
   child-handle transfer, and cleanup action lists attempt all releases while
   retaining the primary error. Native errors are structured without argv/env or
   arbitrary path dumps. Closed fields are cleared; watcher process handles remain
   live until exit wait completes. Denied-API behavior remains a native test gap.
4. Acceptance strength: all 18 original cases remain in order, plus three narrow
   cases. failure requires root exit 7 in retained-handle logs and fixture data;
   breakaway requires ERROR_ACCESS_DENIED=5. Invalid PE requires CreateProcessW=193.
   Actual workload and watchdog limit readbacks are asserted. Unknown identity,
   incomplete accounting or cleanup errors cannot pass original cases. New deliberate
   lock-failure tests require the precise refusal and independent retained-handle
   termination observations; unrelated errors are not accepted as safety evidence.
5. Evidence: workflow initializes custody before runtime setup and always finalizes
   workflow status. Harness setup/ABI/import failures and case cleanup failures get
   bounded receipts with first/secondary errors, unexecuted-case enumeration, and
   independent finally attempts. All relevant rotated operator/watchdog/controller
   logs, fixture/admission/config/runtime markers are retained as raw allowlisted
   bytes in <=1 MiB per-case bundles. Storage/runner-kill failures are reported,
   not magically recoverable; preserve the raw Actions console as fallback.

## Static verification and second source-review pass

The only executable repository check in Cloud is
`python -I tests.py --static-only`, using existing /usr/bin/python3.13 (3.13.5).
The gate parses all four Python files, checks policy invariants, validates manifest
bytes/EOL, and checks native-call arities using AST without native imports.
The final external static receipt accompanies the handoff; it is generated evidence,
not a file uploaded as guardrail source. Exact current source hashes are in the
revised SOURCE-MANIFEST.json; final commit/tree identities are in the handoff.

A dedicated second source pass reviews ABI types/layout and call arities, atomic
job assignment, every process/thread/job/event/mutex ownership transfer, exit and
cleanup ordering, state-lock ordering, epoch/reset transitions, exact acceptance
assertions, and artifact/resource bounds after implementation. Source-review
blockers found in that pass must be corrected before upload. No independent agent
or runtime validation is implied by a second pass by the same reviewer.

Second-pass disposition: completed in hosted Cloud. Corrected the admission-check /
reservation lock gap, added a pre-resume circuit-publication check, refreshed job
accounting after PID reconciliation, made reset interruption persist RESETTING,
preserved primary errors when secondary close operations fail, and tightened fanout
to kernel notification or quota denial with exact attributed starts. Added an exact
owned-process termination/wait path for partial launch failure and retained raw
pre-reset markers before disposable resets remove them. Reviewed the
final ownership, epoch/lock ordering, console flags, 21 case assertions, ABI sizes
and offsets, workflow gates and artifact allowlists. No unresolved source-review
blocker to a disposable diagnostic run was identified. Native correctness and
error-87 resolution remain UNVERIFIED, not inferred from static review.

Final static disposition: PASS under Python 3.13.5. All four Python sources parsed;
26 manifest source/docs/history entries verified; 42 direct native-call arities
checked (including the controller's raw Defender OpenProcess call); policy and
manual-only workflow invariants verified. git diff --check passed. The original
cloud review and old manifest were checked against their preserved copies/baseline.
No Windows case in this revision executed in Cloud.

## Resource-bound review and remaining gaps

Workload cap remains 2 TOTAL processes, <=256 MiB job commit, <=192 MiB per-process
commit, <=20% CPU, 8 seconds aggregate user CPU, and <=20 seconds wall time
(8 seconds in disposable CI copies). Watchdog remains 1 process, 128/96 MiB,
5% CPU, 8 seconds user CPU and an independent wall deadline. Memory-denial attempts
at most 128 MiB; fanout attempts three children; churn attempts twelve sequential
finite children. All console/system helpers still count. No real Git or research
content is used. Controller itself remains uncapped and overhead unmeasured.

Original 18 cases plus three new cases run sequentially, stop at first failed
assertion, and never auto-retry. Extra control helpers are outside the workload
job and finite; the largest simultaneous added group is two stop helpers with
one controller, watchdog and at most two workload members. Control waits are
bounded; a stale-stop barrier expires in eight seconds and state-lock hold is
2.5 seconds. Case controller waits remain 25 seconds; suite admission six minutes,
suite step seven minutes, job ten minutes. The suite admission deadline is checked
between cases; the runner timeout is the hard outer limit. 21 one-MiB raw bundles
plus 21 <=256 KiB case receipts and small metadata remain below unchanged
160-file / 32 MiB upload caps. Per-log 256 KiB / two-backup bounds are unchanged.

Hosted Python is pinned to first-run 3.13.16 x64 without upgrading it. OS still
resolves through windows-latest and exact runner/OS/Python/executable hashes are
recorded. Availability of the pinned runtime/action commits and current hosted OS
is not established here. No new kernel/ctypes/process/console/watchdog/concurrency
claim is runtime verified. Cross-package persistence, external handle interference,
privileged tampering, simultaneous monitor stalls, OS scheduling failure and
desktop/service-brokered escapes remain outside the prototype's qualified scope.
Filesystem-full/write-denial and general denied-API fault injection remain future
acceptance work. Launch-rate enforcement is reactive; production remains disabled.

## Upload and next action

Upload only the explicit reviewed source/docs manifest to the requested branch;
do not upload generated evidence, scripts from /tmp, local notes, credentials or
unrelated files. If push is unavailable, provide a source archive and a JSON text-file
upload payload with hashes and the exact baseline. The originating chat must inspect
the revision and alone dispatch the one separately approved hosted Windows run.
No automatic retry or production/local release is authorized by this report.
