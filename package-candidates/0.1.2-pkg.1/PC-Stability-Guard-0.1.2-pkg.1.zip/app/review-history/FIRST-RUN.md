# Immutable historical disposition (owner-supplied receipts)

Baseline c8e382ec3187f68da2a432cec58d61facd94c50b, candidate 0.1.0.
Run https://github.com/sterlingstreamsllc/windows-stability-guardrail/actions/runs/39643441053
Job 119372733828; artifact 12366187116; artifact SHA256
1fa80db71567c8a228e189f7cd8f4e4b5960119775ea497991b4950fa2ad7163.
Result: FAIL. normal and fanout passed; failure failed; 15 cases UNEXECUTED.
Python 3.13.16 x64; Windows Server 2025 10.0.26100;
runner image windows-2025-vs2026 20261007.264.1.

root-start was followed about 0.1 seconds later by OSError/winerror 87.
Final state OPEN, active=0, total=2, peak job commit=10223616.
Earlier cases observed conhost.exe in the job. No exit-7 event was retained.
Failing API and PID were not recorded. Stale queued PID/transient-process
causation is a hypothesis, not a confirmed diagnosis or pinned-version bug.
No historical failure is reclassified by this revision.

The owner reports all five original run source/config hashes exactly reproduce
LF-to-CRLF conversion of baseline blobs. The old LF hashes remain verbatim in
SOURCE-MANIFEST-0.1.0.json. New .gitattributes requires canonical LF bytes and
the new static/hosted gates verify the full new manifest before native execution.
This chat has not downloaded or independently authenticated the old artifact.
