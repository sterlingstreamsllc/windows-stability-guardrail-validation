# Guardrail-only cloud workspace

Maturity: interim engineering prototype. No IOC or production acceptance is implied.

This repository may contain only guardrail source, synthetic fixtures, and generic
documentation. Do not access research repositories, host drives, production
evidence, credentials, or backups. No Codex desktop launch or real Git test is
authorized here; the small checkout operation belongs to CI setup only.

Use static checks in Codex Cloud. Windows APIs must be tested on the separately
owner-approved GitHub-hosted windows-latest workflow. Never run that workflow
on a self-hosted runner. No automatic push, pull-request or scheduled triggers.
Ask the owner before creating repositories or enabling/dispatching workflows.

Preserve first failures and all raw receipts. Do not convert an unrelated error
into a passing safety assertion. Stop the synthetic suite at its first failed
assertion. New remediation must first get a short targeted official known-issue
check against the observed version/signature, then bounded diagnosis.
Do not substitute tests on the recovering workstation.

Do not claim hard executable-specific or launch-rate enforcement from polling.
The two-process job cap covers all in-job processes. Launch-rate controls for
arbitrary descendants are reactive. Existing desktop and service-brokered
processes remain outside the verified boundary.

No research restoration, security configuration, registry changes, services,
scheduled tasks, startup hooks, Git binary replacement, repository cleanup or
model changes are authorized. Do not initialize any research repository.
No subagents or external messages without owner authorization.
