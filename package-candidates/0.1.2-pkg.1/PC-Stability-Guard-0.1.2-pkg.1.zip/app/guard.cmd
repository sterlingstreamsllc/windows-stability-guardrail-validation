@echo off
setlocal
if not defined PCSG_PYTHON (
  echo Set PCSG_PYTHON to the approved absolute path of 64-bit python.exe.
  exit /b 30
)
if not exist "%PCSG_PYTHON%" (
  echo Approved Python executable not found.
  exit /b 30
)
"%PCSG_PYTHON%" -I "%~dp0guard.py" %*
exit /b %errorlevel%
