# 0.1.2-pkg.1 preparation and second source review

Date: 2026-10-21 UTC. **Complete bundled-runtime candidate; packaged Windows,
staging, rollback and local validation UNEXECUTED. Production DISABLED.**
Read the external PACKAGE-STATIC-RECEIPT.json and SHA256SUMS for exact final
archive, manifest, vendor and file digests; this report cannot contain its own
enclosing ZIP digest. The separate APPROVAL-TEMPLATE.txt binds future proposed
approval to that final digest. No local approval is requested by this delivery.

## Environment and authority

Before shell work, the platform reported provider=cloud, running,
observations_current=true, connected, environment
ccarenv_b64_Y2NhcmVudl81YmYwYzEyYjA0YjA4MTkxOWQxOGNlZGUwY2VhNDgwYw.
Work used only /workspace/windows-stability-guardrail and isolated temporary
packaging directories, existing Cloud Python 3.13.5 for static checks, no
subagents, host mounts, secrets, research data, workloads or Windows execution.
No push, PR, release, workflow change/dispatch, local installation, version
upgrade, security change or stale setup execution occurred. Main and all old
commits/remote branches were preserved. Packaging work is on a local Cloud branch.

The approved www.python.org addition was already present in the draft. Live
status remained revision 1/unknown network state; a fresh proxy-mediated download
after the owner's domain review succeeded. No policy removal/re-add, publication,
script approval or reset was performed here. Configuration activation/restoration
is not inferred from successful access. Python Manager is unrelated and unused.

## Preserved engine and history

All 31 Git blobs at b1c851ef45ec234261685dddcf3cda275f531615 / tree
fe8de7ce07d9aeff3d21df39a6a17315bf4772d4 are byte-identical under app/;
the engine/config/workflow/tests and original SOURCE-MANIFEST.json are unchanged.
The only extra app file is the separately inventoried empty __pycache__ sentinel.
Original c8e382ec3187f68da2a432cec58d61facd94c50b and 0.1.1
255f256ca6525ef190cf8069396f67ae448b57c8 remain historical sources, with both FAIL
records unchanged. Old docs saying 0.1.2 Windows NOT RUN are deliberately kept
as historical tested bytes; HOSTED-RUN-HISTORY.json adds the later owner report.

Owner-verified hosted run 39660566124 passed all 21 cases on image 20261018.275.1
in 63.5735263 suite seconds. The previous failures used image 20261007.264.1.
This is a successful new-image test, not controlled same-image causation or a
retroactive PASS for either failure. Raw CI ZIPs were not repackaged; only source
metadata is included. No fresh native result was generated in Cloud.

## Runtime provenance and integrity

Official Python 3.13.16 AMD64 embeddable ZIP: 11439094 bytes; SHA256
97dae5274cc54867065e8d5a3226e48c35017ed332a0fdb0e27d5b5821961297. Release HTML,
SPDX and Sigstore message digest agree. All 34 vendor files, licenses, ._pth,
catalog, PE signatures and zipped stdlib are unchanged. Safe outer/inner ZIP
entries, bounded expansion and AMD64 PE headers are checked as inert data.
The unchanged stdlib ZIP contains 533 pyc files and eight inventoried ancillary
files, including vendor macholib helper scripts; none were extracted for use or
executed. A draft builder rejected these ancillary files under an overstrict
all-pyc assumption. That static FAIL is retained in BUILD-REVIEW-HISTORY.json;
the corrected composition check requires the exact 541-member vendor inventory.

The bundled python.exe SHA256 is
31fe10b4ed82a2f960af0ef9931f46a4b84ff286f8b6ffd9dee098cf4f10f17f, matching the
owner-reported hosted executable hash. This only establishes equality of that
file: embedded runtime composition, search-path policy, startup and full hosted
runtime equivalence are not established. The vendor ZIP includes 34 files and
an isolated ._pth policy, rather than a full installed Python environment.

Bundled-certificate signature mathematics passes; the certificate states
thomas@python.org. Official SPDX identifies Python Software Foundation, and PE
certificate metadata includes that organization. Independent Fulcio/transparency
trust-policy, Windows Authenticode/revocation and local application control checks
were not performed. Official bundles, vendor license and pinned CPython notices
are retained. Existing host ucrtbase.dll is required; no installer is supplied.

## Source/package review dispositions

1. **Immutable/mutable boundary:** all frozen app/runtime and root files are
   SHA256-verified against the externally anchored manifest. The empty regular
   app/__pycache__ file is hashed and required before runtime commands; unexpected
   code/bytecode and missing source are refused. Pinned importlib tolerates cache
   read/write OSError and compiles source. No engine, ._pth, vendor or ACL changes.
   This design applies to unchanged child `python -I` invocations; Windows
   sentinel behavior is a specific unexecuted smoke target.
2. **Install/path safety:** local fixed per-user root only, fresh directory,
   CreateNew writes, size/type/name/hash checks, no archive links, reparse
   ancestors or overwrite. Partial failures remain for inspection. Checks do not
   claim race-free defense against hostile same-user concurrent mutation.
3. **Emergency availability:** the operator's independent terminal uses direct
   absolute bundled python/guard stop, with no PowerShell script or receipt-tree
   traversal. Optional Package.ps1 Stop checks critical code and exact state leaf
   paths, rejecting dangling/reparse entries, then terminates before evidence
   writes. Partial evidence returns failure without masking an earlier stop error.
   Critical code corruption cannot be safely ignored.
   The guard's existing named-job scope, mutex-independent kill and watchdog are
   unchanged. Stop output and any receipt failure must be preserved.
4. **Evidence/rollback:** unique UTC+GUID snapshots before/after operations,
   bounded retained state/fixture/operator/watchdog/controller files, primary
   failure preservation, no outcome success when snapshot fails. One-normal
   marker prevents repeat admission even after failed preflight. No reset command.
   Quarantine renames only after stopped-state checks; never deletes evidence.
   PreservePartial separately allows a contained whole-root rename from the
   trusted external script when staging/integrity is incomplete, requiring owner
   confirmation of stopped state without reading/executing/following the payload.
5. **Resource/acceptance bounds:** unchanged config, exact workload/watchdog limit
   readbacks, final active0/total1, watchdog exit, complete observation, no cleanup
   errors and normal fixture receipt. Initial floor >=8 GiB physical/>=6 GiB
   commit. Control interpreters/terminals are outside workload quotas; wrapper
   deadlines and retained-output checks are not system-wide resource quotas.
6. **Policy/trust:** no elevation, PATH, service, registry, task, autostart, pip,
   network, Bypass, Unblock or policy repair at install/use. A blocked script is
   an acceptance failure, not permission to re-execute by another route.

The dedicated second source pass occurs after the package edits and checks the
actual final script/doc/manifest bytes. Its receipt is supplied separately as
SECOND-SOURCE-REVIEW.json. Any subsequent source change invalidates that receipt
and requires a new pass and artifact hash. No unresolved source blocker is to be
silently converted into a Windows PASS.

## What integrity checks do and do not establish

Mutable paths are app/state/{runtime,breaker,watchdog-trip,admission}.json and
their unique atomic .new files; controller/watchdog/operator .jsonl logs and two
backups; app/scratch/fixture.json; and bounded local-evidence receipt folders plus
the one-attempt marker. These observations are retained, not authenticated as
truth or trusted executable code. No mutable cache path is allowed. Immutable
vendor stdlib .pyc entries inside the hashed python313.zip are intentional.
The wrapper rejects unknown additional files and executable-looking mutable
files; no package path is appended to global import/environment settings.

SHA256 comparisons establish byte equality to this reviewed artifact. They do
not protect against an owner-level attacker replacing the script/trusted hash,
concurrent malicious mutation, host compromise, filesystem exhaustion or service
broker escape. Engine coverage remains limited to its assigned job, with
reactive descendant identification/rate controls and no coverage of existing
desktop or service-brokered processes. Production use remains disabled.

## Required gaps before acceptance

Windows PowerShell parsing/behavior; .NET ZIP staging and path/reparse checks on
Windows; exact embedded runtime startup/UCRT compatibility; all child imports
with the sentinel; baseline/status/normal wrapper behavior; output capture,
MOTW/policy behavior, emergency operator path and quarantine behavior are all
UNEXECUTED. The complete package has not been installed or run anywhere.
Cloud AST/hash/archive/PE-data checks and the old hosted engine PASS do not close
these gaps. The local plan and separately bounded package-smoke proposal describe
future approvals; no additional run is authorized in this preparation turn.
