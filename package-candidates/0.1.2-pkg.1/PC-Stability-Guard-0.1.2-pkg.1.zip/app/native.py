"""Windows x64 API boundary. Source candidate: NOT runtime-qualified."""
import ctypes as C
from ctypes import wintypes as W
import os
import subprocess

if os.name != "nt" or C.sizeof(C.c_void_p) != 8:
    raise RuntimeError("Requires 64-bit Windows and 64-bit Python")
K = C.WinDLL("kernel32", use_last_error=True)
P = C.WinDLL("psapi", use_last_error=True)
H = W.HANDLE
Z = C.c_size_t
U64 = C.c_ulonglong
PTR = C.c_void_p

def api(dll, name, result, *args):
    f = getattr(dll, name)
    f.restype, f.argtypes = result, list(args)
    return f

_CloseHandle = api(K, "CloseHandle", W.BOOL, H)
CreateJob = api(K, "CreateJobObjectW", H, PTR, W.LPCWSTR)
OpenJob = api(K, "OpenJobObjectW", H, W.DWORD, W.BOOL, W.LPCWSTR)
SetJob = api(K, "SetInformationJobObject", W.BOOL, H, C.c_int, PTR, W.DWORD)
QueryJob = api(K, "QueryInformationJobObject", W.BOOL, H, C.c_int, PTR, W.DWORD, PTR)
KillJob = api(K, "TerminateJobObject", W.BOOL, H, W.UINT)
InJob = api(K, "IsProcessInJob", W.BOOL, H, H, C.POINTER(W.BOOL))
CreatePort = api(K, "CreateIoCompletionPort", H, H, H, Z, W.DWORD)
GetPort = api(K, "GetQueuedCompletionStatus", W.BOOL, H, C.POINTER(W.DWORD),
              C.POINTER(Z), C.POINTER(PTR), W.DWORD)
InitAttrs = api(K, "InitializeProcThreadAttributeList", W.BOOL, PTR, W.DWORD,
                W.DWORD, C.POINTER(Z))
UpdateAttr = api(K, "UpdateProcThreadAttribute", W.BOOL, PTR, W.DWORD,
                 Z, PTR, Z, PTR, PTR)
DeleteAttrs = api(K, "DeleteProcThreadAttributeList", None, PTR)
CreateProcess = api(K, "CreateProcessW", W.BOOL, W.LPCWSTR, W.LPWSTR,
                    PTR, PTR, W.BOOL, W.DWORD, PTR, W.LPCWSTR, PTR, PTR)
Resume = api(K, "ResumeThread", W.DWORD, H)
Wait = api(K, "WaitForSingleObject", W.DWORD, H, W.DWORD)
ExitCode = api(K, "GetExitCodeProcess", W.BOOL, H, C.POINTER(W.DWORD))
OpenProcess = api(K, "OpenProcess", H, W.DWORD, W.BOOL, W.DWORD)
TerminateProcess = api(K, "TerminateProcess", W.BOOL, H, W.UINT)
ImageName = api(K, "QueryFullProcessImageNameW", W.BOOL, H, W.DWORD,
                W.LPWSTR, C.POINTER(W.DWORD))
CreateEvent = api(K, "CreateEventW", H, PTR, W.BOOL, W.BOOL, W.LPCWSTR)
OpenEvent = api(K, "OpenEventW", H, W.DWORD, W.BOOL, W.LPCWSTR)
SetEvent = api(K, "SetEvent", W.BOOL, H)
CreateMutex = api(K, "CreateMutexW", H, PTR, W.BOOL, W.LPCWSTR)
ReleaseMutex = api(K, "ReleaseMutex", W.BOOL, H)

class Basic(C.Structure):
    _fields_ = [("ProcessTime", C.c_longlong), ("JobTime", C.c_longlong),
                ("Flags", W.DWORD), ("MinWS", Z), ("MaxWS", Z),
                ("ActiveLimit", W.DWORD), ("Affinity", Z),
                ("Priority", W.DWORD), ("Scheduling", W.DWORD)]
class IO(C.Structure):
    _fields_ = [(n, U64) for n in ("ReadOps","WriteOps","OtherOps",
                                  "ReadBytes","WriteBytes","OtherBytes")]
class Extended(C.Structure):
    _fields_ = [("Basic", Basic), ("IO", IO), ("ProcessMemory", Z),
                ("JobMemory", Z), ("PeakProcessMemory", Z), ("PeakJobMemory", Z)]
class Accounting(C.Structure):
    _fields_ = [(n, C.c_longlong) for n in ("User","Kernel","PeriodUser","PeriodKernel")] + [
        ("Faults", W.DWORD), ("Total", W.DWORD), ("Active", W.DWORD),
        ("Terminated", W.DWORD)]
class Associate(C.Structure):
    _fields_ = [("Key", PTR), ("Port", H)]
class Cpu(C.Structure):
    _fields_ = [("Flags", W.DWORD), ("Rate", W.DWORD)]
class Startup(C.Structure):
    _fields_ = [("cb", W.DWORD), ("Reserved", W.LPWSTR),
        ("Desktop", W.LPWSTR), ("Title", W.LPWSTR)] + [
        (n, W.DWORD) for n in ("X","Y","XSize","YSize","XChars","YChars",
                              "Fill","Flags")] + [
        ("Show", W.WORD), ("Reserved2Size", W.WORD), ("Reserved2", PTR),
        ("Input", H), ("Output", H), ("Error", H)]
class StartupEx(C.Structure):
    _fields_ = [("Startup", Startup), ("Attributes", PTR)]
class ProcessInfo(C.Structure):
    _fields_ = [("Process", H), ("Thread", H), ("Pid", W.DWORD), ("Tid", W.DWORD)]
class MemoryStatus(C.Structure):
    _fields_ = [("Length", W.DWORD), ("Load", W.DWORD)] + [
        (n, U64) for n in ("TotalPhys","AvailPhys","TotalPage","AvailPage",
                           "TotalVirtual","AvailVirtual","AvailExtended")]
class Performance(C.Structure):
    _fields_ = [("cb", W.DWORD)] + [(n, Z) for n in (
        "CommitTotal","CommitLimit","CommitPeak","PhysicalTotal","PhysicalAvailable",
        "SystemCache","KernelTotal","KernelPaged","KernelNonpaged","PageSize")] + [
        ("Handles", W.DWORD), ("Processes", W.DWORD), ("Threads", W.DWORD)]
class Entry(C.Structure):
    _fields_ = [("Size", W.DWORD), ("Usage", W.DWORD), ("Pid", W.DWORD),
        ("Heap", Z), ("Module", W.DWORD), ("Threads", W.DWORD),
        ("Parent", W.DWORD), ("Priority", W.LONG), ("Flags", W.DWORD),
        ("Exe", W.WCHAR * 260)]
class Counters(C.Structure):
    _fields_ = [("cb", W.DWORD), ("PageFaults", W.DWORD)] + [
        (n, Z) for n in ("PeakWS","WS","PeakPaged","Paged","PeakNonPaged",
                         "NonPaged","PageFile","PeakPageFile","Private")]
GlobalMemory = api(K, "GlobalMemoryStatusEx", W.BOOL, C.POINTER(MemoryStatus))
PerformanceInfo = api(P, "GetPerformanceInfo", W.BOOL, C.POINTER(Performance), W.DWORD)
Snapshot = api(K, "CreateToolhelp32Snapshot", H, W.DWORD, W.DWORD)
First = api(K, "Process32FirstW", W.BOOL, H, C.POINTER(Entry))
Next = api(K, "Process32NextW", W.BOOL, H, C.POINTER(Entry))
ProcessMemory = api(P, "GetProcessMemoryInfo", W.BOOL, H, PTR, W.DWORD)
ProcessTimes = api(K, "GetProcessTimes", W.BOOL, H, PTR, PTR, PTR, PTR)

class NativeError(OSError):
    def __init__(self, operation, pid=None, winerror=None):
        self.operation, self.pid = operation, pid
        code = C.get_last_error() if winerror is None else winerror
        super().__init__(code, operation)
        self.winerror = code

    def receipt(self):
        return {"operation":self.operation, "pid":self.pid, "winerror":self.winerror}

def check(value, operation, pid=None):
    if not value:
        raise NativeError(operation, pid)
    return value

def close(handle):
    if handle:
        check(_CloseHandle(handle), "CloseHandle")

def cleanup(actions):
    """Attempt every release; callers retain their first error separately."""
    errors = []
    for operation, action in actions:
        try:
            action()
        except BaseException as ex:
            errors.append(error_context(ex, operation))
    return errors

def error_context(ex, operation=None):
    result = {"type":type(ex).__name__}
    if isinstance(ex, NativeError):
        result.update(ex.receipt())
    elif isinstance(ex, OSError):
        result.update(operation=operation, winerror=getattr(ex,"winerror",None))
    else:
        result["operation"] = operation
        result["reason"] = str(ex)[:256] if isinstance(ex, RuntimeError) else type(ex).__name__
    result.update(getattr(ex, "observation_context", {}))
    return result

def wait_exit(handle, milliseconds=3000, pid=None):
    result = Wait(handle, milliseconds)
    if result == 258:
        raise RuntimeError("PROCESS_TERMINATION_NOT_CONFIRMED")
    if result != 0:
        raise NativeError("WaitForSingleObject", pid)

def system_memory():
    m, p = MemoryStatus(), Performance()
    m.Length, p.cb = C.sizeof(m), C.sizeof(p)
    check(GlobalMemory(C.byref(m)), "GlobalMemoryStatusEx")
    check(PerformanceInfo(C.byref(p), C.sizeof(p)), "GetPerformanceInfo")
    return {"available": int(m.AvailPhys),
            "commit_headroom": int((p.CommitLimit-p.CommitTotal)*p.PageSize)}

def process_snapshot():
    """One native snapshot; no WMI, child command, or file-tree scan."""
    s = check(Snapshot(2, 0), "CreateToolhelp32Snapshot")
    if s == C.c_void_p(-1).value:
        raise NativeError("CreateToolhelp32Snapshot")
    result = []
    try:
        e = Entry()
        e.Size = C.sizeof(e)
        ok = First(s, C.byref(e))
        while ok:
            result.append((int(e.Pid), int(e.Parent), str(e.Exe)))
            if len(result) >= 8192:
                raise RuntimeError("PROCESS_SNAPSHOT_TOO_LARGE")
            ok = Next(s, C.byref(e))
        if C.get_last_error() != 18:  # ERROR_NO_MORE_FILES
            raise NativeError("Process32FirstW/Process32NextW")
    except BaseException as ex:
        ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + cleanup([("CloseSnapshot", lambda:close(s))])
        raise
    else:
        close(s)
    return result

def memory_and_cpu(handle, pid=None):
    m = Counters()
    m.cb = C.sizeof(m)
    check(ProcessMemory(handle, C.byref(m), C.sizeof(m)), "GetProcessMemoryInfo", pid)
    a, b, c, d = U64(), U64(), U64(), U64()
    check(ProcessTimes(handle, C.byref(a), C.byref(b), C.byref(c), C.byref(d)), "GetProcessTimes", pid)
    return {"working_set": int(m.WS), "private_bytes": int(m.Private),
            "cpu_seconds": (c.value+d.value)/10000000}

def process_handle(pid):
    return check(OpenProcess(0x1000 | 0x100000, False, pid), "OpenProcess", pid)

def image_name(handle, pid=None):
    size, buf = W.DWORD(32768), C.create_unicode_buffer(32768)
    check(ImageName(handle, 0, buf, C.byref(size)), "QueryFullProcessImageNameW", pid)
    return buf.value

def exit_code(handle, pid=None):
    # GetExitCode alone cannot distinguish a still-running process from exit 259.
    status = Wait(handle, 0)
    if status == 258:
        return None
    if status != 0:
        raise NativeError("WaitForSingleObject", pid)
    v = W.DWORD()
    check(ExitCode(handle, C.byref(v)), "GetExitCodeProcess", pid)
    return int(v.value)

class Mutex:
    def __init__(self, name="Local\\PCSG-v010-single-controller", timeout=0):
        self.h = check(CreateMutex(None, False, name), "CreateMutexW")
        result = Wait(self.h, timeout)
        if result not in (0, 0x80):
            original = (NativeError("WaitForSingleObject") if result != 258 else
                        RuntimeError("ANOTHER_CONTROLLER_OR_RESET_IS_ACTIVE"))
            original.cleanup_errors = cleanup([("CloseHandle", lambda:close(self.h))])
            self.h = None
            raise original
        self.abandoned = result == 0x80
    def close(self):
        handle, self.h = self.h, None
        if handle:
            errors = cleanup([("ReleaseMutex", lambda:check(ReleaseMutex(handle), "ReleaseMutex")),
                              ("CloseHandle", lambda:close(handle))])
            if errors:
                raise RuntimeError("MUTEX_CLEANUP_FAILED_"+str(errors))
    def __enter__(self):
        return self
    def __exit__(self, kind, value, trace):
        try:
            self.close()
        except BaseException as ex:
            if kind is None:
                raise
            value.cleanup_errors = getattr(value, "cleanup_errors", []) + [error_context(ex, "Mutex.close")]

class Event:
    def __init__(self, name, create=False, manual=False):
        if create:
            self.h = check(CreateEvent(None, manual, False, name), "CreateEventW")
            if C.get_last_error() == 183:
                ex = RuntimeError("EVENT_NAME_COLLISION")
                ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + cleanup([("CloseCollidingEvent", lambda:close(self.h))])
                self.h = None
                raise ex
        else:
            self.h = check(OpenEvent(0x100002, False, name), "OpenEventW")
    def set(self):
        check(SetEvent(self.h), "SetEvent")
    def wait(self, milliseconds=0):
        r = Wait(self.h, milliseconds)
        if r not in (0, 258):
            raise NativeError("WaitForSingleObject.Event")
        return r == 0
    def close(self):
        handle, self.h = self.h, None
        close(handle)

class Job:
    def __init__(self, name, policy=None):
        self.h = self.port = None
        try:
            if policy is None:
                self.h = check(OpenJob(0x0C, False, name), "OpenJobObjectW")  # QUERY | TERMINATE
                return
            self.h = check(CreateJob(None, name), "CreateJobObjectW")
            if C.get_last_error() == 183:
                raise RuntimeError("JOB_NAME_COLLISION")
            e = Extended()
            # Active, job/process commit, kill-on-last-close, aggregate user CPU time.
            # No BREAKAWAY_OK or SILENT_BREAKAWAY_OK.
            e.Basic.Flags = 0x8 | 0x200 | 0x100 | 0x2000 | 0x4
            e.Basic.ActiveLimit = policy["max_active_processes"]
            e.Basic.JobTime = int(policy["job_user_cpu_seconds"] * 10000000)
            e.ProcessMemory = policy["max_process_memory_mib"] * 1048576
            e.JobMemory = policy["max_job_memory_mib"] * 1048576
            check(SetJob(self.h, 9, C.byref(e), C.sizeof(e)), "SetInformationJobObject")
            cpu = Cpu(1 | 4, policy["cpu_percent"] * 100)
            check(SetJob(self.h, 15, C.byref(cpu), C.sizeof(cpu)), "SetInformationJobObject")
            # Read back hard limits before any workload can start.
            actual = self.extended()
            if (actual.Basic.Flags != e.Basic.Flags or
                actual.Basic.ActiveLimit != e.Basic.ActiveLimit or
                actual.JobMemory != e.JobMemory or
                actual.ProcessMemory != e.ProcessMemory or
                actual.Basic.JobTime != e.Basic.JobTime):
                raise RuntimeError("JOB_LIMIT_READBACK_MISMATCH")
            actual_cpu = Cpu()
            check(QueryJob(self.h, 15, C.byref(actual_cpu), C.sizeof(actual_cpu), None), "QueryInformationJobObject")
            if actual_cpu.Flags != cpu.Flags or actual_cpu.Rate != cpu.Rate:
                raise RuntimeError("CPU_LIMIT_READBACK_MISMATCH")
            self.port = check(CreatePort(C.c_void_p(-1), None, 0, 1), "CreateIoCompletionPort")
            assoc = Associate(1, self.port)
            check(SetJob(self.h, 7, C.byref(assoc), C.sizeof(assoc)), "SetInformationJobObject")
        except BaseException as ex:
            ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + cleanup([("Job.close", self.close)])
            raise

    def extended(self):
        e = Extended()
        check(QueryJob(self.h, 9, C.byref(e), C.sizeof(e), None), "QueryInformationJobObject")
        return e

    def accounting(self):
        a = Accounting()
        check(QueryJob(self.h, 1, C.byref(a), C.sizeof(a), None), "QueryInformationJobObject")
        return {"total": int(a.Total), "active": int(a.Active),
                "terminated": int(a.Terminated), "cpu": (a.User+a.Kernel)/10000000}

    def pids(self):
        # Header + 64 pointer-sized PIDs; policy active <=2.
        buf = C.create_string_buffer(8+64*C.sizeof(Z))
        check(QueryJob(self.h, 3, buf, C.sizeof(buf), None), "QueryInformationJobObject")
        assigned, count = (W.DWORD*2).from_buffer(buf)
        if assigned > 64 or count > 64:
            raise RuntimeError("JOB_PID_OVERFLOW")
        return list((Z*count).from_buffer(buf, 8))

    def contains(self, handle, pid=None):
        v = W.BOOL()
        check(InJob(handle, self.h, C.byref(v)), "IsProcessInJob", pid)
        return bool(v.value)

    def event(self, timeout=100):
        msg, key, pid = W.DWORD(), Z(), PTR()
        if not GetPort(self.port, C.byref(msg), C.byref(key), C.byref(pid), timeout):
            if C.get_last_error() == 258:
                return None
            raise NativeError("GetQueuedCompletionStatus")
        return int(msg.value), int(pid.value or 0)

    def terminate(self, code=0xE0470001):
        check(KillJob(self.h, code), "TerminateJobObject")

    def close(self):
        port, handle = self.port, self.h
        self.port = self.h = None
        errors = cleanup([("CloseCompletionPort", lambda:close(port)),
                          ("CloseJobHandle", lambda:close(handle))])
        if errors:
            raise RuntimeError("JOB_HANDLE_CLOSE_FAILED_"+str(errors))

    def limits(self):
        e = self.extended()
        cpu = Cpu()
        check(QueryJob(self.h, 15, C.byref(cpu), C.sizeof(cpu), None),
              "QueryInformationJobObject.Cpu")
        return {"flags":int(e.Basic.Flags), "active_limit":int(e.Basic.ActiveLimit),
                "job_memory":int(e.JobMemory), "process_memory":int(e.ProcessMemory),
                "job_user_time":int(e.Basic.JobTime), "cpu_flags":int(cpu.Flags),
                "cpu_rate":int(cpu.Rate)}

def launch(job, argv, cwd, environment=None):
    """Atomic job assignment at process creation; no create/assign orphan window."""
    if not os.path.isabs(argv[0]) or not os.path.isfile(argv[0]):
        raise ValueError("ABSOLUTE_EXISTING_EXECUTABLE_REQUIRED")
    if not os.path.isabs(cwd) or not os.path.isdir(cwd):
        raise ValueError("ABSOLUTE_EXISTING_WORKDIR_REQUIRED")
    size = Z()
    InitAttrs(None, 1, 0, C.byref(size))
    if not size.value:
        raise NativeError("InitializeProcThreadAttributeList.Size")
    attrs = C.create_string_buffer(size.value)
    check(InitAttrs(attrs, 1, 0, C.byref(size)), "InitializeProcThreadAttributeList")
    pi = ProcessInfo()
    try:
        handles = (H*1)(job.h)
        check(UpdateAttr(attrs, 0, 0x2000D, handles, C.sizeof(handles), None, None), "UpdateProcThreadAttribute")
        sx = StartupEx()
        sx.Startup.cb, sx.Attributes = C.sizeof(sx), C.addressof(attrs)
        cmd = C.create_unicode_buffer(subprocess.list2cmdline(argv))
        envbuf = None
        if environment is not None:
            envbuf = C.create_unicode_buffer(
                "\0".join(k+"="+v for k,v in sorted(environment.items(),
                                                   key=lambda x:x[0].upper()))+"\0\0")
        # EXTENDED_STARTUPINFO | SUSPENDED | UNICODE_ENVIRONMENT | DETACHED_PROCESS.
        # Do not combine DETACHED_PROCESS with CREATE_NO_WINDOW/NEW_CONSOLE.
        # All system-generated members still count toward limits and attribution.
        check(CreateProcess(argv[0], cmd, None, None, False,
              0x80000 | 4 | 0x400 | 0x8,
              envbuf, cwd, C.byref(sx), C.byref(pi)), "CreateProcessW")
        if not job.contains(pi.Process, int(pi.Pid)):
            raise RuntimeError("ATOMIC_JOB_ASSIGNMENT_NOT_CONFIRMED")
        return pi
    except BaseException as ex:
        actions = []
        if pi.Process:
            # Exact handle returned by our own CreateProcessW, never a PID/name kill.
            # Also covers a failed membership check without trusting that check.
            def stop_owned():
                if exit_code(pi.Process, int(pi.Pid)) is None:
                    check(TerminateProcess(pi.Process, 0xE0470001),
                          "TerminateProcess.OwnedLaunch", int(pi.Pid))
            actions.extend([("TerminateOwnedLaunch", stop_owned),
                            ("TerminateJobObject", job.terminate),
                            ("WaitOwnedLaunch", lambda:wait_exit(pi.Process,3000,int(pi.Pid)))])
        actions.extend([("CloseProcess", lambda:close(pi.Process)),
                        ("CloseThread", lambda:close(pi.Thread))])
        ex.cleanup_errors = getattr(ex,"cleanup_errors",[]) + cleanup(actions)
        raise
    finally:
        DeleteAttrs(attrs)

def resume(pi):
    if Resume(pi.Thread) == 0xFFFFFFFF:
        raise NativeError("ResumeThread", int(pi.Pid))
    close(pi.Thread)
    pi.Thread = None

