# Validation contract

Maturity: interim engineering prototype. **Revised 0.1.2 Windows runtime cases are NOT RUN.**
Static parsing is not proof of ctypes ABI correctness, process containment, reliable
termination, acceptable overhead or research usability.

## Static gate

Review ctypes signatures, x64 layout, startup attributes, handle ownership,
exception cleanup, secret-safe logs, hard-limit readback, persistent crash state and
singleton/reset races. Parse source/configuration and inspect workflow scope.
Windows ABI assertions remain a separate first step on the hosted runner.

## Bounded hosted suite

Only GitHub-hosted Windows is admitted by the executable harness. Each case gets a
small fresh synthetic folder, runs sequentially and has an outer 25-second wait.
One workflow has a ten-minute timeout and the suite has a six-minute admission
deadline. Stop at the first failed assertion; do not relabel infrastructure errors
as safety passes. Fixtures are finite even if the candidate controller fails.

| Case | Required observation |
|---|---|
| normal | Assigned root exits 0; job empty; clean close |
| fanout | Kernel process-limit message or fixture launch denial/failure; no >2 observed active |
| failure | Exact exit 7 is logged; circuit opens; subsequent launch refused |
| memory-denial | Kernel memory-limit message or explicit allocation denial; peak within job limit |
| hang | Wall timeout; empty job |
| failed-launch | Inspected AMD64 DLL rejected by CreateProcessW with exactly error 193; zero workload starts |
| parent-exit | Root exit with live descendant triggers tree termination |
| breakaway | CREATE_BREAKAWAY_FROM_JOB is denied; finite fallback child cannot silently pass |
| pressure | Injected low available-memory sample trips after hysteresis |
| commit-pressure | Injected low commit-headroom sample trips after hysteresis |
| controller-hang | Independent watchdog logs heartbeat loss and terminates job |
| watchdog-exit | Controller notices loss and stops job |
| churn | Finite sequence trips cumulative start-rate policy |
| git-fanout | Synthetic git.exe identity observed; total process cap applies |
| git-rate | Synthetic Git starts observed; reactive rate trip |
| emergency | Emergency command empties job; unrelated dummy remains alive |
| controller-kill | Held member process handles signal after exact controller termination |
| admission | Second broker request refused before any new workload launch |

The suite uses a NEW tiny compiled dummy named git.exe in runner temporary storage;
it does not rename or replace the Git installation and does not execute real Git
commands. This proves only process-image classification and generic containment,
not compatibility with Git for Windows helpers, credential managers, hooks or LFS.

The workstation's 6 GiB stop floors are not appropriate to blindly apply to a small
hosted VM. Disposable CI case copies use explicitly labeled 512 MiB floors and a
1 GiB warning, retaining the same <=256 MiB workload caps. The main config is not
modified. Injected pressure tests change input readings, never system memory or
pagefile settings. The memory-denial fixture attempts at most 128 MiB.

## Additional release acceptance targets

- Independently inspect raw receipts and demonstrate controller/watchdog/child
  termination, especially startup interruption, lost notifications and denied APIs.
- Measure controller + watchdog CPU, private memory, handles, disk writes and log
  growth over a bounded idle/busy sample. No measured overhead claim exists yet.
- Exercise log/state write failure, malformed config, concurrent launch/reset,
  PID reuse assumptions, job nesting under the exact host, and restart after crash.
- Add tests for denied event/job access and status/emergency handle interference.
- Verify cooperative graceful cancellation and an immutable checkpoint adapter
  before admitting research. Current mode is immediate synthetic termination.
- Strict launch-rate prevention for arbitrary descendants is NOT DEMONSTRATED.
  If required, implement a mediated launch-only interface plus a demonstrably
  non-bypassable execution envelope; do not weaken acceptance to match polling.
- Test actual Codex startup/activation only after separate approval, in containment
  that can be demonstrated before workload execution. Existing desktop coverage
  is UNPROTECTED, not a successful Gate C.
- Bundle the validated interpreter and license, freeze source/config hashes,
  record OS/interpreter/runner image identity, and create a release manifest.
- Owner acceptance and local installation authorization remain separate.

## Maturity dispositions

- IOC BLOCKER for the desktop mission: relevant desktop Git tree is outside this
  candidate boundary. This is a known architecture limitation.
- NOT DEMONSTRATED acceptance targets: runtime enforcement, emergency reliability,
  overhead, research adapter and exact rate control. Missing proof alone is not
  a diagnosis of unusability.
- IOC ACCEPTABLE DEFECT in the synthetic envelope: stop on first failure, manual
  reset, restrictive two-process budget, and incomplete noncritical telemetry.
- FOC MATURATION ISSUE unless core impact is shown: dashboards, automatic recovery,
  service integration and broad performance instrumentation.

No historical research or qualification disposition is rescored.

## 0.1.1 acceptance refinements

All 18 original cases remain in their original order. Three cases follow:

- concurrent-control: competing launch/reset overlap a live controller and must
  both be refused; two stops terminate its workload during a finite controller stall.
- stop-under-state-lock: a CI-only helper holds the publication mutex for 2.5 seconds;
  stop must terminate retained workload process handles before lock acquisition,
  then report the expected publication-lock refusal. Retained watchdog handles
  must signal as well. OPEN_RUN after failed final publication is an expected
  fail-closed observation in this deliberate lock-failure case, never a clean close.
- stale-stop-generation: a bounded test barrier captures an old stop request, then
  another stop finishes and disposable state is explicitly reset. Releasing the old
  request must refuse its stale epoch without changing the new reset state.

Hooks require the hosted CI synthetic profile, stay finite, and cannot run through
the cloud static gate. No new workload limits or retry allowance is introduced.
Exact exit 7 is required from the retained root handle and fixture receipt. Breakaway
requires winerror 5, not an arbitrary OSError. Native limit values (including CPU,
commit and active-process caps) are in runtime evidence and asserted independently.
Unknown identities, incomplete accounting, cleanup errors and unrelated errors do
not pass original cases. The original invalid text fixture asserted error 193 and
failed with 216 in the 0.1.1 run; SECOND-RUN.md preserves that FAIL.

Evidence initializes before native import/ABI/setup, with workflow-level receipts
before Python setup. Per-case finally paths attempt all cleanup/capture steps and
preserve first failures separately from secondary errors. Each case retains raw
allowlisted fixture/admission/operator/watchdog/controller/runtime/config bytes in
a <=1 MiB ZIP bundle, plus a <=256 KiB case receipt. Rotated logs are included.
Bundles preserve pre-reset/before-backoff snapshots as well as final cleanup state;
disposable reset cannot erase the captured trip/admission evidence.
21 pairs plus bounded workflow/setup/static/build/summary files remain below the
unchanged 160-file / 32 MiB upload caps; logs remain <=256 KiB with two backups.
Failure of artifact storage/upload itself is a failure, with console as fallback;
no program can guarantee artifact writes after filesystem failure or runner kill.

Six-minute between-case admission, 25-second controller wait, seven-minute suite
step and ten-minute workflow job remain. Case cleanup has finite individual waits;
the workflow timeout is the final outer bound, not a proof every receipt survives
forced runner shutdown. No automatic retest follows any failure. Review all 21 case
outcomes and all unexecuted cases, not just workflow color.

## 0.1.2 failed-launch contract

Compile the same finite GitStub.cs with the same installed compiler using
/target:library /platform:x64. The byte-only inspector requires bounded DOS/PE
headers, AMD64 0x8664, PE32+ 0x20b, executable and DLL flags, nonoverlapping section
extents, bounded directories and CLR metadata, IL-only x64 and no managed entry
point. This is a narrow fixture inspector, not a general PE validity verifier.
The harness verifies source/compiler/output hashes and build options. Controller
and harness independently re-read the same disposable copy and retain its parsed
structure and build provenance in setup, summary, runtime and per-case receipts.
Compiler timestamps may vary; the exact compiled bytes are hashed per run.
The <=4 KiB PE headers and 72-byte CLR header are retained as hex for independent
structural inspection, within the existing receipt limits.

Required first error is precisely NativeError / CreateProcessW / 193 / null PID.
216 and unrelated errors still FAIL. The workload's final total, active, terminated,
CPU and peak commit must all be zero, with complete process attribution. There
must be one fixture-attributed attempt, no root PID/start/resume or child/exit event,
confirmed watchdog exit, no cleanup errors, and unchanged hard-limit readbacks.
Unexpected successful creation is terminated while suspended and fails the case;
the DLL is never intentionally resumed or loaded by the byte inspector.
Admission must refuse the open circuit without changing its runtime state, followed
by a successful explicit reset of disposable state. Both command receipts survive.

Microsoft's DLL/PE guidance motivates this fixture, but does not establish a
universal exact CreateProcessW=193 guarantee. The one prospective hosted run must
prove that result for its recorded compiler, DLL, Python and runner image. No native
result is inferred from the Cloud static byte checks. All 21 cases, ordering,
first-failure stop and existing bounds remain; no retries or broader error set.
