@echo off
call "%~dp0guard.cmd" status
exit /b %errorlevel%
