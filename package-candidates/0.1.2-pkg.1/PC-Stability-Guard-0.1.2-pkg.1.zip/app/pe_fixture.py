"""Bounded, byte-only inspection of the compiled failed-launch DLL; never loads it."""
import hashlib
import struct

MAX_BYTES = 1048576
KIND = "finite-csharp-amd64-dll-v1"

def inspect_dll(data):
    def require(condition, reason):
        if not condition:
            raise ValueError("FAILED_LAUNCH_FIXTURE_"+reason)

    def bounds(offset, size):
        require(0 <= offset <= len(data) and 0 <= size <= len(data)-offset, "BOUNDS")

    def u16(offset):
        bounds(offset, 2)
        return struct.unpack_from("<H", data, offset)[0]

    def u32(offset):
        bounds(offset, 4)
        return struct.unpack_from("<I", data, offset)[0]

    require(64 <= len(data) <= MAX_BYTES, "SIZE")
    require(data[:2] == b"MZ", "DOS_SIGNATURE")
    pe = u32(0x3c)
    require(pe >= 64 and pe % 4 == 0, "PE_OFFSET")
    bounds(pe, 24)
    require(data[pe:pe+4] == b"PE\0\0", "PE_SIGNATURE")
    machine, count = u16(pe+4), u16(pe+6)
    optional_size, characteristics = u16(pe+20), u16(pe+22)
    require(machine == 0x8664, "AMD64_REQUIRED")
    require(1 <= count <= 96, "SECTION_COUNT")
    require(characteristics & 0x2002 == 0x2002, "EXECUTABLE_DLL_REQUIRED")
    require(optional_size == 240, "PE32_PLUS_HEADER_SIZE")
    optional = pe+24
    bounds(optional, optional_size)
    require(u16(optional) == 0x20b, "PE32_PLUS_REQUIRED")
    section_alignment, file_alignment = u32(optional+32), u32(optional+36)
    require(512 <= file_alignment <= 65536 and file_alignment & (file_alignment-1) == 0,
            "FILE_ALIGNMENT")
    require(section_alignment >= file_alignment and
            section_alignment & (section_alignment-1) == 0, "SECTION_ALIGNMENT")
    image_size, header_size = u32(optional+56), u32(optional+60)
    table = optional+optional_size
    bounds(table, count*40)
    require(table+count*40 <= header_size <= len(data) and
            header_size % file_alignment == 0, "HEADER_EXTENT")
    require(header_size <= 4096, "HEADER_RECEIPT_BOUND")
    require(image_size >= header_size and image_size % section_alignment == 0, "IMAGE_EXTENT")
    sections = []
    for i in range(count):
        offset = table+i*40
        virtual_size, rva, raw_size, raw = (u32(offset+n) for n in (8,12,16,20))
        require(rva >= header_size and rva % section_alignment == 0 and
                rva+max(virtual_size,raw_size) <= image_size, "SECTION_IMAGE_EXTENT")
        bounds(raw,raw_size)
        if raw_size:
            require(raw >= header_size and raw % file_alignment == 0 and
                    raw_size % file_alignment == 0, "SECTION_FILE_EXTENT")
        for prior in sections:
            require(not raw_size or not prior[2] or
                    raw+raw_size <= prior[3] or prior[3]+prior[2] <= raw, "SECTION_OVERLAP")
            require(rva+max(virtual_size,raw_size) <= prior[0] or
                    prior[0]+max(prior[1],prior[2]) <= rva, "RVA_OVERLAP")
        sections.append((rva,virtual_size,raw_size,raw))

    def file_offset(rva, size):
        for start, virtual_size, raw_size, raw in sections:
            if start <= rva and rva-start+size <= raw_size:
                return raw+rva-start
        raise ValueError("FAILED_LAUNCH_FIXTURE_UNMAPPED_DIRECTORY")

    require(u32(optional+108) == 16, "DIRECTORY_COUNT")
    for i in range(16):
        rva, size = u32(optional+112+i*8), u32(optional+116+i*8)
        if rva or size:
            require(rva > 0 and size > 0, "DIRECTORY_PAIR")
            bounds(rva if i == 4 else file_offset(rva,size), size)  # certificate uses file offset
    clr_rva, clr_size = u32(optional+224), u32(optional+228)
    require(clr_rva > 0 and clr_size == 72, "CLR_HEADER")
    clr = file_offset(clr_rva,clr_size)
    require(u32(clr) == 72 and u32(clr+16) & 1 and not u32(clr+16) & 2, "CLR_IL_ONLY_X64")
    require(u32(clr+20) == 0, "DLL_HAS_NO_MANAGED_ENTRY_POINT")
    metadata_size = u32(clr+12)
    require(metadata_size >= 16, "METADATA_SIZE")
    metadata = file_offset(u32(clr+8),metadata_size)
    require(data[metadata:metadata+4] == b"BSJB", "CLR_METADATA_SIGNATURE")
    return {"kind":KIND, "bytes":len(data), "sha256":hashlib.sha256(data).hexdigest(),
            "pe_offset":pe, "machine":machine, "optional_magic":u16(optional),
            "characteristics":characteristics, "sections":count,
            "header_bytes":header_size, "image_bytes":image_size,
            "headers_hex":data[:header_size].hex(), "clr_header_hex":data[clr:clr+clr_size].hex(),
            "clr_bytes":clr_size, "clr_flags":u32(clr+16),
            "metadata_rva":u32(clr+8), "metadata_bytes":metadata_size,
            "managed_entry_point":u32(clr+20)}
