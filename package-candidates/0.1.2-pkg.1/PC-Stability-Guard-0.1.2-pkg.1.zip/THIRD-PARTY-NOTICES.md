# Runtime redistribution and notices

The complete official Python 3.13.16 AMD64 embeddable distribution is included
under runtime/, unmodified: all 34 files, including LICENSE.txt, python.cat,
python313._pth, zipped standard library and signed PE files. No pip, dependency
installation, runtime patch, vendor signature mutation or UCRT installer is added.

Read runtime/LICENSE.txt in full. Additional official pinned PSF license and
incorporated-software notices are retained verbatim in
provenance/CPYTHON-LICENSE.txt and provenance/python-third-party-license.rst.
The latter includes PSF/history, OpenSSL Apache 2.0, expat, libffi, zlib,
libmpdec, HACL*, Unicode and other incorporated-source notices. These augment,
not replace, the vendor distribution's notices, including Microsoft
Distributable Code terms. No new third-party library is bundled by this project.

provenance/python-3.13.16-embed-amd64.zip.spdx.json is the supplier's complete
SPDX document, including its original version, supplier, dependency and
NOASSERTION fields. A package listed by the supplier does not itself prove a
separately shipped DLL or a licensed component's runtime use in this package.
Exact shipped files and their hashes are in RUNTIME-PROVENANCE.json. The embedded
distribution omits Tcl/Tk functionality even where vendor notices mention it.

The runtime is supplied by the Python Software Foundation, as recorded in the
official SPDX. The official Sigstore bundle is retained; bundled-certificate
signature mathematics and the archive digest were checked. This is not a claim
of independent Sigstore transparency/chain-policy or Windows Authenticode trust
verification. Runtime publisher identity/digest evidence and its limits are
recorded in OFFICIAL-SOURCES.md and provenance/RUNTIME-PROVENANCE.json.

The system Microsoft C Runtime (ucrtbase.dll) is a host prerequisite. The package
does not install it or modify Windows. The complete vendor runtime is bundled;
"self-contained" here means no separately installed Python/Git/pip or install/use
network dependency, not a copy of Windows or proof of host compatibility.
