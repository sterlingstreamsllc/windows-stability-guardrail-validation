# Proposed local validation — 0.1.2-pkg.1

**UNEXECUTED. Remote preparation is the only current authority.** This document
does not authorize staging, interpreter execution, a Windows test, or a workload.
Production launch remains disabled. Read the separate verification report and
external APPROVAL-TEMPLATE.txt for the actual package and script hashes.

The tested engine is b1c851ef45ec234261685dddcf3cda275f531615. All 31 tested
files are retained byte for byte under app/. This new package adds an immutable
zero-byte app/__pycache__ file and an untested embeddable-runtime installation
boundary. The hosted full-runtime 21/21 result does not qualify this package.

## 0. Owner preparation, before any local approval

Close Codex/ChatGPT desktop, including tray processes, and any background Git
started by them. Do not open a research repository. Use ordinary standalone
PowerShell 5.1 and CMD terminals; no agent session executes this plan. Do not
scan C:\AI, C:\work, J-GRAM, USEFM, or any other research directory. No real Git,
pip, downloads, global Python, compiler, elevated terminal, services, registry,
tasks, autostart, PATH/profile changes, or security changes are needed.

Review the complete package ZIP as inert data and this plan first. Record its
SHA256 from the independently supplied SHA256SUMS, not from a manifest inside an
untrusted archive. Confirm an AMD64 Windows host, existing system ucrtbase.dll,
enough disk space for 128 MiB expanded payload plus 32 MiB receipts, and a fresh
user-writable destination:

`[actual LocalApplicationData]\PC-Stability-Guard-0.1.2-pkg.1`

Use the actual absolute path, not a placeholder or an environment override.
The supplied script accepts only that fixed per-user root. Existing directories,
UNC/device paths, reparse ancestors, and protected/research locations are refused.
Do not overwrite or remove an old installation to make this one succeed.

## 1. Separately approved static staging only

First obtain explicit approval identifying the complete ZIP SHA256 and exact
fresh directory, limited to file inspection and staging. See INSTALL-ROLLBACK.md
for the exact commands. Verify the standalone Package.ps1 digest before invoking
it, then InspectArchive, Stage, and InspectInstalled with the external manifest
digest. Stage only copies verified files; it never starts Python or a fixture.
Retain the console transcript outside the frozen payload in the owner's chosen
receipt location. No credentials or unrelated data belong in that transcript.

If execution policy, application control, SmartScreen or downloaded-file marking
blocks any step: **stop before any fixture**. Preserve the exact error and step.
Leave policy, trust, Zone.Identifier and security settings unchanged. No
Unblock-File, Set-ExecutionPolicy, Bypass (including process-only), encoded/inline
re-execution of a blocked script, or alternate transfer to strip markings.
This is a future environment acceptance result, not permission to repair it.

Inspect unchanged runtime/python313._pth, runtime/LICENSE.txt, supplied licenses,
SPDX, provenance, and manifests. Confirm app/__pycache__ is a zero-byte regular
file with the empty SHA256. Unknown code or missing frozen source is a refusal.
No package Python is started during this stage.

## 2. Separately approved initial runtime trial — one normal only

This stage needs a second approval identifying the same ZIP hash, exact root,
the single `normal` case, all caps below, and emergency stop if it misbehaves.
The initial approval excludes every hang, failure, concurrency, emergency-stop
exercise, reset, retry, suite invocation, compiler fixture, and real workload.

Before admission, use Task Manager's Performance/Memory display to record
available physical memory and committed current/limit values. Require at least
8 GiB available physical RAM and 6 GiB commit headroom (limit minus committed).
If uncertain or unsuitable, stop; never lower thresholds. This visual check does
not replace the bundled Baseline probe immediately before the one admission.
Record time, idle CPU, available memory, commit current/limit/headroom, and disk
free space. Do not collect a process list or scan user directories.

Prepare a separate standalone CMD terminal with the exact absolute command from
OPERATOR-CARD.txt. Do not execute stop as a rehearsal: that would be a separate
exercise. Ensure the path points to this verified instance. The direct command
uses no PowerShell script, global PATH, network, or mutable-tree enumeration.

After approval, run Package.ps1 Baseline and Status once. Baseline must report
Python 3.13.16, isolated mode, at least 8589934592 available bytes and 6442450944
commit headroom bytes. Status must indicate NOT_STARTED/production DISABLED.
These two short commands start the bundled interpreter but admit no workload.
Any anomalous return, unexpected native dialog, prompt, path or resource change
ends the stage. Preserve receipts; do not proceed to normal.

Run Package.ps1 Normal **once**. It creates a non-overwriting attempt marker,
rechecks baseline headroom, requires fresh runtime state, and admits only normal.
Normal sleeps 0.5 seconds, writes `{"normal":true}`, and exits. It creates no
children. The immutable two-process policy still accounts for any additional
system-created in-job process; no exception is made for console processes.

| Boundary | Unchanged/configured cap or package deadline |
| --- | --- |
| Workload Job Object | At most 2 active processes; normal acceptance requires total 1, final active 0 |
| Workload commit | 256 MiB job, 192 MiB per process |
| Workload CPU | 20% hard rate, 8 aggregate user CPU seconds |
| Workload elapsed | 20 seconds engine wall deadline, polling every 1 second |
| Independent watchdog job | 1 process, 128 MiB job, 96 MiB process, 5% CPU, 8 user CPU seconds |
| Watchdog timing | Heartbeat 4 seconds; absolute engine wall+8 = 28 seconds |
| Wrapper waits | Baseline/status 8 seconds each; normal 35 seconds, then at most 3 seconds waiting for termination of its exact owned controller |
| System floors | Warning available physical 8 GiB; stop physical 6 GiB and commit headroom 6 GiB, 3 critical samples; never reduce |
| Admissions | One attempt marker, original rate maximum 10/60 seconds, retries 0; no repeat or reset |
| Engine logs | Controller/watchdog/operator, 256 KiB per file with 2 backups each; state JSON at most 32 KiB each |
| Package receipts | Unique UTC+GUID folders; at most 256 KiB per mutable file, 32 MiB total; snapshots at most 64 files/8 MiB; console output at most 32 KiB per stream checked on command completion |

The PowerShell/CMD terminals, controller and short baseline/status/stop helpers
are outside the workload job. Their interpreter memory/CPU is **not** hard-capped
by its 256 MiB/20% limits. The expected simultaneous normal topology is one
fixture, one controller, one watchdog, and the already open terminals; emergency
stop adds one short helper. The wrapper has bounded waits, not an OS-wide quota.
Log rotation bounds retained log size; it is not a kernel I/O-rate limit. Disk
output limits are checked, not a filesystem quota. These limits do not cover
other desktop apps, existing processes, services or brokered processes.

If Normal has not completed within **10 seconds measured from starting the
Normal command in the owner's terminal**, use the prepared independent Stop and
end the attempt, even if no job was admitted. This conservative owner intervention
does not alter the 20-second engine, 28-second watchdog or 35+3-second wrapper
deadlines. NO_IDENTIFIED_JOB alone does not prove cleanup. The direct path assumes
already verified trusted code and a quiescent owner session; it does not guarantee
protection from hostile concurrent filesystem mutation.

On this timeout or the first other anomaly, use the prepared direct Stop command immediately, retain
its console output, and cease the trial. It targets only this recorded named
workload job. No broad PID/name kill, unrelated process termination, automatic
reset, second normal attempt, threshold change or software update is authorized.
If stop itself fails, preserve the exact error; do not improvise a retry or claim
cleanup succeeded. Independent watchdog and last-handle job cleanup remain the
engine's mechanisms, but local behavior is not established until observed.

## 3. Acceptance and evidence preservation

Require normal controller exit 0, CLOSED, COMPLETE process observation, final
active 0/total 1, watchdog_exit_confirmed true, no cleanup errors, exact normal
fixture receipt and unchanged workload/watchdog limit readbacks. The wrapper
checks those conditions and frozen file hashes again. Retain unique before/after
state, fixture, operator/watchdog/controller receipts and all command output.
Any absent receipt, integrity failure or failed assertion is a FAIL, not a reason
to retry. Initial trial has no reset. Do not run the historical app/*.cmd wrappers.

The snapshot directories are unique and never overwritten. This candidate
forbids any later admission, including after a failed baseline. Future separately
authorized admission tooling must snapshot existing runtime.json before it can
be replaced; deleting the marker is not an authorized reset.

## 4. Reversible rollback, without deleting evidence

After verifying stopped state, record the package hash, manifest hash and all
receipt directory names. With explicit rollback approval, Quarantine renames the
whole directory to a unique sibling; it does not delete files. See
INSTALL-ROLLBACK.md. If exit or integrity cannot be confirmed, leave it untouched
for review. For partial staging or damaged integrity, the separately approved
PreservePartial action from the verified external script can rename the fixed
root without reading/executing the payload, only after explicit owner confirmation
that no commands from it are running. No running processes should be relocated. Restoring a quarantined
directory or another admission requires separate authorization.

## Separate future package-smoke proposal

Before local trial, the originating chat may propose one separately authorized
hosted AMD64 Windows package smoke job, manual only, job timeout 10 minutes and
internal timeout 7 minutes, pinned Python package bytes, no dependencies/network.
It would use the exact final ZIP hash, fresh per-user directory, static staging,
one Baseline, one Status, one Normal, frozen/vendor hash recheck, sentinel
regular-file check, evidence retention, then evidence-preserving quarantine.
It must have at least 8 GiB available physical and 6 GiB commit headroom; otherwise
it stops without lowering config. No full 21-case rerun, hang/emergency/concurrency
exercise, retries, production data or dispatch is included in this proposal.
No workflow was added or changed for it. All package-specific Windows behavior
is UNEXECUTED at delivery. Later phases need their own bounded approval.
